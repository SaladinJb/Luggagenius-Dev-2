import React, { useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, Send, Mail, MessageSquare, User } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setFormData({ name: "", email: "", message: "" });
      setSubmitted(false);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F8F8F8]">
      <style>{`
        .frosted-glass {
          background: rgba(255, 255, 255, 0.03);
          backdrop-filter: blur(40px);
          -webkit-backdrop-filter: blur(40px);
          border: 1px solid rgba(255, 255, 255, 0.08);
        }

        .glow-purple {
          box-shadow: 0 0 40px rgba(107, 54, 255, 0.3);
        }

        .input-glow:focus-within {
          box-shadow: 0 0 30px rgba(107, 54, 255, 0.4);
        }
      `}</style>

      {/* Ambient background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div 
          className="absolute top-40 right-20 w-[500px] h-[500px] rounded-full blur-[120px] opacity-20"
          style={{ background: 'radial-gradient(circle, #6B36FF 0%, transparent 70%)' }}
        />
        <div 
          className="absolute bottom-20 left-20 w-[600px] h-[600px] rounded-full blur-[140px] opacity-15"
          style={{ background: 'radial-gradient(circle, #D94CFF 0%, transparent 70%)' }}
        />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 py-20">
        {/* Back button */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-12"
        >
          <Link to={createPageUrl("Home")}>
            <Button variant="ghost" className="text-[#C8CDD3] hover:text-[#F8F8F8] hover:bg-white/5">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Home
            </Button>
          </Link>
        </motion.div>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-[#6B36FF] via-[#D94CFF] to-[#D2FF4D] bg-clip-text text-transparent">
            Get in Touch
          </h1>
          <p className="text-xl text-[#C8CDD3] max-w-2xl mx-auto">
            Need support for a specific airline? We're here to help expand our coverage.
          </p>
        </motion.div>

        {/* Contact Form */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="frosted-glass rounded-3xl p-8 md:p-12 glow-purple"
        >
          {submitted ? (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-center py-12"
            >
              <div className="w-20 h-20 bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] rounded-full flex items-center justify-center mx-auto mb-6">
                <Send className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold mb-4">Message Sent!</h2>
              <p className="text-[#C8CDD3] text-lg">
                We'll get back to you as soon as possible.
              </p>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-[#C8CDD3] mb-3 flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Your Name
                </label>
                <div className="frosted-glass rounded-2xl input-glow transition-all duration-300">
                  <Input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="bg-transparent border-0 text-lg text-[#F8F8F8] placeholder-[#C8CDD3]/50 px-6 py-4"
                    placeholder="John Doe"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#C8CDD3] mb-3 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Email Address
                </label>
                <div className="frosted-glass rounded-2xl input-glow transition-all duration-300">
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    className="bg-transparent border-0 text-lg text-[#F8F8F8] placeholder-[#C8CDD3]/50 px-6 py-4"
                    placeholder="john@example.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#C8CDD3] mb-3 flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  Your Message
                </label>
                <div className="frosted-glass rounded-2xl input-glow transition-all duration-300">
                  <Textarea
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    required
                    rows={6}
                    className="bg-transparent border-0 text-lg text-[#F8F8F8] placeholder-[#C8CDD3]/50 px-6 py-4 resize-none"
                    placeholder="Tell us which airline you'd like us to support..."
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-[#6B36FF] to-[#D94CFF] hover:opacity-90 text-white text-lg py-6 rounded-2xl font-medium transition-all duration-300"
              >
                <Send className="w-5 h-5 mr-2" />
                Send Message
              </Button>
            </form>
          )}
        </motion.div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-12 text-center text-[#C8CDD3]"
        >
          <p className="text-lg">
            Covering 160+ IATA registered airlines and growing every day
          </p>
        </motion.div>
      </div>
    </div>
  );
}