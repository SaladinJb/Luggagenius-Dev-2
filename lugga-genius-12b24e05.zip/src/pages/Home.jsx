
import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Shield, Zap, Globe, CheckCircle, ArrowRight, ArrowLeft, Sun, Moon, Ruler, Menu, X as CloseIcon } from "lucide-react";
import SearchBox from "../components/home/SearchBox";
import StatsCard from "../components/home/StatsCard";
import FloatingObjects from "../components/home/FloatingObjects";
import RotatingText from "../components/home/RotatingText";
import AllowancePanel from "../components/allowances/AllowancePanel";
import EnforcementWidget from "../components/allowances/EnforcementWidget";
import ComparisonBanner from "../components/allowances/ComparisonBanner";
import StickyUpsellBar from "../components/allowances/StickyUpsellBar";
import Footer from "../components/home/Footer";
import { useTheme } from "../components/ThemeProvider";
import { useUnitSystem } from "../components/UnitSystemProvider";
import GeniusPackerAI from "../components/journey/GeniusPackerAI";

const SUPABASE_URL = "https://ejwzyaipwxxnrkcmjelx.supabase.co";
const SUPABASE_KEY = "sb_publishable_ZjLVjnPNTd0Eg4E3wUJqtA_kRb7a2Ki";

const ALLOWANCE_TYPES = ["personal_item", "carry_on", "checked", "special_items"];

const TYPE_DISPLAY_NAMES = {
  "personal_item": "Personal Item",
  "carry_on": "Carry-on",
  "checked": "Checked",
  "special_items": "Special Items"
};

export default function Home() {
  const [activeAirlinesCount, setActiveAirlinesCount] = useState(0);
  const [brandLogos, setBrandLogos] = useState({ lightMode: null, darkMode: null });
  
  const [isMultiJourneyMode, setIsMultiJourneyMode] = useState(false);
  const [journeys, setJourneys] = useState([{ id: Date.now() }]);
  
  const [resetTrigger, setResetTrigger] = useState(0);
  const [hasAnimated, setHasAnimated] = useState(false);
  const [activeTab, setActiveTab] = useState('home');
  const [showNav, setShowNav] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const { theme, toggleTheme } = useTheme();
  const { unitSystem, toggleUnitSystem } = useUnitSystem();

  const showResults = journeys.some(j => j.showResults);
  const shouldUseResultsLayout = showResults;

  const bothJourneysComplete = isMultiJourneyMode && 
    journeys[0]?.showResults && 
    journeys[0]?.airline && 
    journeys[0]?.allowances && 
    journeys[0]?.filters &&
    Object.keys(journeys[0].filters).length > 0 &&
    journeys[1]?.showResults && 
    journeys[1]?.airline && 
    journeys[1]?.allowances &&
    journeys[1]?.filters &&
    Object.keys(journeys[1].filters).length > 0;

  useEffect(() => {
    if (isMultiJourneyMode && journeys.length === 2) {
      const bothEmpty = !journeys[0]?.showResults && !journeys[1]?.showResults;
      if (bothEmpty) {
        setIsMultiJourneyMode(false);
        setJourneys([{ id: Date.now() }]);
      }
    }
  }, [journeys, isMultiJourneyMode]);

  useEffect(() => {
    fetchAirlinesCount();
    fetchBrandLogos();
  }, []);

  const fetchBrandLogos = async () => {
    try {
      const cacheBuster = `?t=${Date.now()}`;
      
      const [colorBlackRes, colorRes] = await Promise.all([
        fetch(
          `${SUPABASE_URL}/rest/v1/brand_assets?variant=eq.color_black&file_type=eq.svg&active=eq.true&select=public_url`,
          { 
            headers: { 
              apikey: SUPABASE_KEY, 
              Authorization: `Bearer ${SUPABASE_KEY}`,
              'Cache-Control': 'no-cache, no-store, must-revalidate',
              'Pragma': 'no-cache'
            } 
          }
        ),
        fetch(
          `${SUPABASE_URL}/rest/v1/brand_assets?variant=eq.color&file_type=eq.svg&active=eq.true&select=public_url`,
          { 
            headers: { 
              apikey: SUPABASE_KEY, 
              Authorization: `Bearer ${SUPABASE_KEY}`,
              'Cache-Control': 'no-cache, no-store, must-revalidate',
              'Pragma': 'no-cache'
            } 
          }
        )
      ]);
      
      const colorBlackData = await colorBlackRes.json();
      const colorData = await colorRes.json();
      
      setBrandLogos({
        lightMode: Array.isArray(colorBlackData) && colorBlackData.length > 0 
          ? `${colorBlackData[0].public_url}${cacheBuster}` 
          : null,
        darkMode: Array.isArray(colorData) && colorData.length > 0 
          ? `${colorData[0].public_url}${cacheBuster}` 
          : null
      });
    } catch (error) {
      console.error("Error fetching brand logos:", error);
    }
  };

  const fetchAirlinesCount = async () => {
    try {
      const allowancesRes = await fetch(
        `${SUPABASE_URL}/rest/v1/allowances?select=airline_id`,
        { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } }
      );
      
      const allowances = await allowancesRes.json();
      const uniqueAirlineIds = [...new Set((Array.isArray(allowances) ? allowances : []).map(a => a.airline_id))];
      
      if (uniqueAirlineIds.length > 0) {
        const airlinesRes = await fetch(
          `${SUPABASE_URL}/rest/v1/airlines?id=in.(${uniqueAirlineIds.join(',')})&active=eq.true&last_refreshed_at=not.is.null&select=id`,
          { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, Prefer: "count=exact" } }
        );
        
        const countHeader = airlinesRes.headers.get('content-range');
        if (countHeader) {
          setActiveAirlinesCount(parseInt(countHeader.split('/')[1]));
        } else {
          const airlines = await airlinesRes.json();
          setActiveAirlinesCount(Array.isArray(airlines) ? airlines.length : 0);
        }
      }
    } catch (error) {
      console.error("Error fetching airlines count:", error);
    }
  };

  const handleAddAnotherFlight = () => {
    if (journeys.length < 4) {
      setIsMultiJourneyMode(true);
      setJourneys([...journeys, { id: Date.now() }]);
    }
  };

  const handleReset = () => {
    setIsMultiJourneyMode(false);
    setJourneys([{ id: Date.now() }]);
    setHasAnimated(false);
    setResetTrigger(prev => prev + 1);
  };

  const handleRemoveSecondAirline = () => {
    setIsMultiJourneyMode(false);
    setJourneys([journeys[0]]);
  };

  const handleLogoClick = () => {
    handleReset();
    setActiveTab('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY > 100) {
        if (currentScrollY > lastScrollY) {
          setShowNav(false);
          setMobileMenuOpen(false);
        } else {
          setShowNav(true);
        }
      } else {
        setShowNav(true);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  return (
    <div className="app-container">
      <style>{`
        :root {
          --bg-primary: #F5F5F7;
          --bg-secondary: #E8E8ED;
          --bg-tertiary: #DCDCE4;
          --text-primary: #1A1A1A;
          --text-secondary: #4A5568;
          --text-tertiary: #718096;
          --border-color: rgba(0, 0, 0, 0.08);
          --border-color-strong: rgba(0, 0, 0, 0.12);
          --glass-bg: rgba(255, 255, 255, 0.7);
          --glass-bg-strong: rgba(255, 255, 255, 0.9);
          --glass-border: rgba(0, 0, 0, 0.08);
          --glass-shadow: rgba(0, 0, 0, 0.08);
          --shadow-color: rgba(0, 0, 0, 0.1);
          --gradient-primary: linear-gradient(135deg, #6B36FF 0%, #D94CFF 100%);
          --gradient-glow: rgba(107, 54, 255, 0.15);
          --ambient-1: 0.056;
          --ambient-2: 0.042;
          --ambient-3: 0.028;
          --search-glow: rgba(107, 54, 255, 0.2);
          --card-bg: rgba(255, 255, 255, 0.55);
          --card-border: rgba(0, 0, 0, 0.1);
          --hover-bg: rgba(0, 0, 0, 0.03);
          --badge-bg: rgba(0, 0, 0, 0.08);
          --badge-text: #2D3748;
          --note-bg: rgba(107, 54, 255, 0.08);
          --note-border: rgba(107, 54, 255, 0.2);
          --note-text: #5B21B6;
          --warning-yellow: #D97706;
          --warning-yellow-bg: rgba(217, 119, 6, 0.1);
          --warning-yellow-border: rgba(217, 119, 6, 0.3);
          --warning-yellow-badge: rgba(217, 119, 6, 0.15);
          --filter-text: #4A5568;
          --filter-text-selected: #5B21B6;
          --filter-bg: rgba(107, 54, 255, 0.08);
          --filter-bg-hover: rgba(107, 54, 255, 0.15);
          --filter-border: rgba(107, 54, 255, 0.25);
          --filter-border-hover: rgba(107, 54, 255, 0.4);
        }

        [data-theme="dark"] {
          --bg-primary: #0A0A0A;
          --bg-secondary: #1A1A1A;
          --bg-tertiary: #2A2A2A;
          --text-primary: #F8F8F8;
          --text-secondary: #C8CDD3;
          --text-tertiary: #9CA3AF;
          --border-color: rgba(255, 255, 255, 0.08);
          --border-color-strong: rgba(255, 255, 255, 0.12);
          --glass-bg: rgba(10, 10, 10, 0.7);
          --glass-bg-strong: rgba(10, 10, 10, 0.9);
          --glass-border: rgba(255, 255, 255, 0.05);
          --glass-shadow: rgba(0, 0, 0, 0.3);
          --shadow-color: rgba(0, 0, 0, 0.3);
          --gradient-glow: rgba(107, 54, 255, 0.2);
          --ambient-1: 0.14;
          --ambient-2: 0.105;
          --ambient-3: 0.07;
          --search-glow: rgba(107, 54, 255, 0.3);
          --card-bg: rgba(255, 255, 255, 0.04);
          --card-border: rgba(255, 255, 255, 0.08);
          --card-border-subtle: rgba(255, 255, 255, 0.12);
          --hover-bg: rgba(255, 255, 255, 0.05);
          --badge-bg: rgba(255, 255, 255, 0.1);
          --badge-text: #E2E8F0;
          --note-bg: rgba(107, 54, 255, 0.15);
          --note-border: rgba(107, 54, 255, 0.3);
          --note-text: #C4B5FD;
          --warning-yellow: #FFD93D;
          --warning-yellow-bg: rgba(255, 217, 61, 0.15);
          --warning-yellow-border: rgba(255, 217, 61, 0.3);
          --warning-yellow-badge: rgba(255, 217, 61, 0.2);
          --filter-text: #C8CDD3;
          --filter-text-selected: #F8F8F8;
          --filter-bg: rgba(107, 54, 255, 0.15);
          --filter-bg-hover: rgba(107, 54, 255, 0.25);
          --filter-border: rgba(107, 54, 255, 0.3);
          --filter-border-hover: rgba(107, 54, 255, 0.5);
        }

        .app-container {
          min-height: 100vh;
          background: var(--bg-primary);
          color: var(--text-primary);
          transition: background 0.3s ease, color 0.3s ease;
          position: relative;
        }

        .app-container::before {
          content: '';
          position: fixed;
          inset: 0;
          background-image: url('https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ea2a47e606ea8412b24e05/db3208dfd_20250915_2333_AirTravelIconsPattern_remix_01k57mmkv5e2f8zaaa70v74xy3.png');
          background-size: 800px;
          background-repeat: repeat;
          background-position: center;
          opacity: 0;
          z-index: 0;
          pointer-events: none;
          transition: opacity 0.5s ease;
        }

        [data-theme="light"] .app-container::before {
          opacity: 0.15;
        }

        @keyframes hue-flow {
          0% { filter: hue-rotate(0deg); }
          100% { filter: hue-rotate(15deg); }
        }

        /* Unified card styling - all cards use feature-card style */
        .frosted-glass,
        .feature-card {
          transition: all 0.3s ease;
          background: var(--card-bg);
          backdrop-filter: blur(40px) saturate(180%);
          -webkit-backdrop-filter: blur(40px) saturate(180%);
          border: 1px solid var(--card-border);
          box-shadow: 0 4px 20px var(--glass-shadow);
        }

        [data-theme="dark"] .frosted-glass,
        [data-theme="dark"] .feature-card {
          border: 1px solid var(--card-border-subtle);
        }

        .feature-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 8px 30px var(--glass-shadow);
        }

        .genius-capsule {
          display: inline-block;
          background: var(--gradient-primary);
          padding: 0.25rem 1rem;
          border-radius: 9999px;
          color: white;
        }

        .enhanced-search-box {
          filter: drop-shadow(0 10px 40px var(--search-glow));
          border-radius: 1rem;
          position: relative;
          z-index: 100;
        }

        .logo-clickable {
          cursor: pointer;
          transition: opacity 0.2s ease;
        }

        .logo-clickable:hover {
          opacity: 0.8;
        }

        .ambient-bg {
          position: fixed;
          inset: 0;
          pointer-events: none;
          z-index: 0;
          transition: opacity 0.5s ease;
        }

        .ambient-gradient {
          position: absolute;
          border-radius: 50%;
          filter: blur(120px);
        }

        .top-nav {
          position: sticky;
          top: 0;
          z-index: 1000;
          background: transparent;
          transform: translateY(0);
          transition: transform 0.3s ease, opacity 0.3s ease;
        }

        .top-nav.nav-hidden {
          transform: translateY(-100%);
          opacity: 0;
          pointer-events: none;
        }

        .mobile-nav {
          display: flex;
          align-items: center; /* Changed from flex-start to center */
          justify-content: space-between;
          padding: 0.75rem 1rem;
          background: var(--glass-bg-strong);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          border-bottom: 1px solid var(--border-color);
        }

        /* Removed mobile-nav-logo-section */
        /* Removed mobile-nav-tagline */

        .mobile-nav-logo {
          cursor: pointer;
          height: 2rem;
          width: auto;
          transition: opacity 0.2s ease;
        }

        .mobile-nav-logo:hover {
          opacity: 0.8;
        }

        .mobile-nav-actions {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        /* Mobile menu outside of nav container */
        .mobile-menu-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          z-index: 1100;
          opacity: 0;
          visibility: hidden;
          pointer-events: none;
          transition: opacity 0.3s ease, visibility 0.3s ease;
        }

        .mobile-menu-overlay.open {
          opacity: 1;
          visibility: visible;
          pointer-events: all;
        }

        .mobile-menu {
          position: fixed;
          top: 0;
          right: 0;
          bottom: 0;
          width: 75%;
          max-width: 18rem;
          background: var(--glass-bg-strong);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          border-left: 1px solid var(--border-color);
          z-index: 1200;
          transform: translateX(100%);
          transition: transform 0.3s ease;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
        }

        .mobile-menu.open {
          transform: translateX(0);
        }

        .mobile-menu-header {
          padding: 0.875rem 1rem;
          border-bottom: 1px solid var(--border-color);
          display: flex;
          align-items: center;
          justify-content: flex-end;
        }

        .mobile-menu-nav {
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          padding: 1.5rem 0;
        }

        .mobile-menu-tab {
          position: relative;
          padding: 0.875rem 1.5rem;
          font-size: 0.9375rem;
          font-weight: 500;
          color: var(--text-secondary);
          background: transparent;
          border: none;
          text-align: left;
          width: 100%;
          cursor: pointer;
          transition: color 0.3s ease;
          border-left: 3px solid transparent;
        }

        .mobile-menu-tab:hover {
          color: var(--text-primary);
          /* background: var(--hover-bg); Removed background hover */
        }

        .mobile-menu-tab.active {
          color: var(--text-primary);
          border-left-color: #6B36FF; /* Added */
          background: var(--hover-bg); /* Added for active state */
        }

        .mobile-menu-footer {
          padding: 0.875rem 1rem;
          border-top: 1px solid var(--border-color);
          display: flex;
          justify-content: center;
          gap: 0.75rem;
        }

        .desktop-nav {
          display: none;
        }

        @media (min-width: 1024px) {
          .mobile-nav {
            display: none;
          }

          .mobile-menu-overlay,
          .mobile-menu {
            display: none;
          }

          .desktop-nav {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            align-items: center;
            padding: 1rem 2rem;
            width: 100%;
          }
          
          .desktop-nav > .nav-tabs-center {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 3rem;
            grid-column: 2;
          }
          
          .desktop-nav > .nav-toggle-group {
            grid-column: 3;
            justify-self: end;
          }
        }

        .nav-tab {
          position: relative;
          padding: 0.5rem 0;
          font-size: 0.9375rem;
          font-weight: 500;
          color: var(--text-secondary);
          cursor: pointer;
          background: none;
          border: none;
          transition: color 0.3s ease;
        }

        .nav-tab:hover {
          color: var(--text-primary);
        }

        .nav-tab.active {
          color: var(--text-primary);
        }

        .nav-tab::after {
          content: '';
          position: absolute;
          bottom: 0;
          left: 0;
          right: 0;
          height: 2px;
          background: var(--gradient-primary);
          transform: scaleX(0);
          transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .nav-tab:hover::after {
          transform: scaleX(1);
        }

        .nav-tab.active::after {
          transform: scaleX(1);
        }

        .nav-toggle-group {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          padding: 0.5rem 0;
        }

        .nav-toggle-btn {
          width: 2rem;
          height: 2rem;
          border-radius: 0.5rem;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--hover-bg);
          border: 1px solid var(--border-color);
          color: var(--text-primary);
          cursor: pointer;
          transition: all 0.2s ease;
          position: relative;
        }

        .nav-toggle-btn:hover {
          background: var(--badge-bg);
          border-color: var(--border-color-strong);
        }

        .nav-toggle-btn:active {
          transform: scale(0.9);
        }

        @keyframes toggle-pulse {
          0% {
            transform: scale(1);
            box-shadow: 0 0 0 0 rgba(107, 54, 255, 0.4);
          }
          50% {
            transform: scale(1.05);
            box-shadow: 0 0 0 8px rgba(107, 54, 255, 0);
          }
          100% {
            transform: scale(1);
            box-shadow: 0 0 0 0 rgba(107, 54, 255, 0);
          }
        }

        .nav-toggle-btn.toggled {
          animation: toggle-pulse 0.4s ease;
          background: rgba(107, 54, 255, 0.1);
          border-color: rgba(107, 54, 255, 0.3);
        }

        .rotating-text-wrapper {
          position: relative;
          z-index: 1;
        }

        @media (max-width: 1023px) {
          .rotating-text-wrapper {
            background: transparent;
            backdrop-filter: none;
            -webkit-backdrop-filter: none;
            padding: 0;
            border-radius: 0;
            margin: 0 auto;
            max-width: 100%;
            box-shadow: none;
          }

          .ambient-bg {
            opacity: 0.5;
          }
        }

        .search-boxes-sticky {
          position: sticky;
          top: 0;
          z-index: 100;
          background: var(--glass-bg-strong);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          padding: 0.75rem 0;
          margin: 0 0 1rem 0;
          border-bottom: 1px solid var(--border-color);
          box-shadow: 0 4px 12px var(--shadow-color);
        }

        @media (max-width: 1023px) {
          .search-boxes-sticky.multi-journey-compact {
            padding: 0.375rem 0;
          }

          .multi-journey-compact .multi-journey-search-grid {
            gap: 0.375rem;
          }

          .multi-journey-compact .search-box-container {
            padding: 0.375rem !important;
          }

          .multi-journey-compact .frosted-glass {
            border-radius: 0.5rem !important;
          }

          .multi-journey-compact .search-box-container > div {
            padding: 0.375rem !important;
          }

          .multi-journey-compact .search-box-container img,
          .multi-journey-compact .search-box-container .w-7,
          .multi-journey-compact .search-box-container .w-8 {
            width: 1.5rem !important;
            height: 1.5rem !important;
          }

          .multi-journey-compact .search-box-container span {
            font-size: 0.75rem !important;
          }

          .multi-journey-compact .search-box-container button {
            padding: 0.25rem !important;
          }

          .multi-journey-compact .search-box-container button[style*="badge"] {
            padding: 0.125rem 0.375rem !important;
            font-size: 0.65rem !important;
          }
        }

        .multi-journey-search-grid {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }

        @media (min-width: 1024px) {
          .multi-journey-search-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
          }
        }

        .results-grid-multi {
          display: flex;
          flex-direction: column;
          gap: 1rem;
          overflow-x: auto;
          overflow-y: visible;
          scroll-behavior: smooth;
          -webkit-overflow-scrolling: touch;
          scrollbar-width: none;
          -ms-overflow-style: none;
          padding: 0;
          position: relative;
        }
        @media (min-width: 1024px) {
          .results-grid-multi {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1.5rem;
            overflow-x: visible;
            overflow-y: visible;
            flex-direction: row;
          }
        }

        .results-grid-multi::-webkit-scrollbar {
          display: none;
        }

        .results-grid-multi-container {
          position: relative;
        }

        .results-grid-multi-container::after {
          content: '';
          position: fixed;
          top: 0;
          bottom: 0;
          right: 0;
          width: 6rem;
          background: linear-gradient(to left, var(--bg-primary), transparent);
          pointer-events: none;
          z-index: 10;
          opacity: 0.9;
        }

        @media (min-width: 1024px) {
          .results-grid-multi-container::after {
            display: none;
          }
        }

        .journey-column {
          flex: 0 0 92.5%;
          display: flex;
          flex-direction: column;
          gap: 1rem;
          min-width: 0;
        }

        @media (min-width: 640px) {
          .journey-column {
            flex: 0 0 85%;
          }
        }

        @media (min-width: 768px) {
          .journey-column {
            flex: 0 0 80%;
          }
        }

        @media (min-width: 1024px) {
          .journey-column {
            flex: none;
          }
        }

        .journey-label-mobile {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 0.75rem;
          background: var(--note-bg);
          border: 1px solid var(--note-border);
          border-radius: 0.75rem;
        }

        .journey-label-mobile .journey-number {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 1.5rem;
          height: 1.5rem;
          border-radius: 50%;
          background: var(--gradient-primary);
          color: white;
          font-size: 0.75rem;
          font-weight: bold;
          flex-shrink: 0;
        }

        .journey-label-mobile .journey-airline {
          font-size: 0.875rem;
          font-weight: 600;
          color: var(--text-primary);
          flex: 1;
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        @media (min-width: 1024px) {
          .journey-label-mobile {
            display: none;
          }
        }
        
        @media (max-width: 640px) {
          .frosted-glass,
          .feature-card {
            border-radius: 1rem;
          }
          
          .genius-capsule {
            padding: 0.2rem 0.75rem;
            font-size: 0.875rem;
          }

          .search-boxes-sticky {
            padding: 0.5rem 0;
          }
        }
        
        @media (hover: none) and (pointer: coarse) {
          button, a, [role="button"] {
            min-height: 44px;
            min-width: 44px;
          }
        }
        
        @media (prefers-reduced-motion: reduce) {
          *,
          *::before,
          *::after {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
            scroll-behavior: auto !important;
          }
          
          .results-grid-multi {
            scroll-behavior: auto;
          }
        }

        *:focus-visible {
          outline: 2px solid #6B36FF;
          outline-offset: 2px;
          border-radius: 0.25rem;
        }
      `}</style>

      <div className="ambient-bg">
        <div 
          className="ambient-gradient top-20 left-20 w-[500px] h-[500px]"
          style={{ 
            background: 'radial-gradient(circle, #6B36FF 0%, transparent 70%)', 
            opacity: 'var(--ambient-1)'
          }}
        />
        <div 
          className="ambient-gradient bottom-20 right-20 w-[600px] h-[600px]"
          style={{ 
            background: 'radial-gradient(circle, #D94CFF 0%, transparent 70%)', 
            opacity: 'var(--ambient-2)'
          }}
        />
        <div 
          className="ambient-gradient top-1/2 left-1/2 w-[400px] h-[400px]"
          style={{ 
            background: 'radial-gradient(circle, #9D50FF 0%, transparent 70%)', 
            opacity: 'var(--ambient-3)'
          }}
        />
      </div>

      {!shouldUseResultsLayout && <FloatingObjects />}

      {/* Mobile menu portal - outside nav */}
      <div className={`mobile-menu-overlay ${mobileMenuOpen ? 'open' : ''}`} onClick={() => setMobileMenuOpen(false)} />
      <div className={`mobile-menu ${mobileMenuOpen ? 'open' : ''}`}>
        <div className="mobile-menu-header">
          <button
            onClick={() => setMobileMenuOpen(false)}
            className="nav-toggle-btn"
            aria-label="Close menu"
          >
            <CloseIcon className="w-4 h-4" />
          </button>
        </div>
        <div className="mobile-menu-nav">
          <button
            className={`mobile-menu-tab ${activeTab === 'product' ? 'active' : ''}`}
            onClick={() => {
              setActiveTab('product');
              setMobileMenuOpen(false);
            }}
          >
            Product
          </button>
          <button
            className={`mobile-menu-tab ${activeTab === 'about' ? 'active' : ''}`}
            onClick={() => {
              setActiveTab('about');
              setMobileMenuOpen(false);
            }}
          >
            About
          </button>
          <button
            className={`mobile-menu-tab ${activeTab === 'corporate' ? 'active' : ''}`}
            onClick={() => {
              setActiveTab('corporate');
              setMobileMenuOpen(false);
            }}
          >
            Corporate Solutions
          </button>
        </div>
        <div className="mobile-menu-footer">
          <motion.button
            onClick={() => {
              toggleUnitSystem();
              const btn = document.querySelectorAll('.unit-toggle-btn');
              btn.forEach(b => b?.classList.add('toggled'));
              setTimeout(() => btn.forEach(b => b?.classList.remove('toggled')), 400);
            }}
            className="nav-toggle-btn unit-toggle-btn"
            aria-label={`Switch to ${unitSystem === "metric" ? "imperial" : "metric"} units`}
            title={`Currently: ${unitSystem === "metric" ? "Metric (kg/cm)" : "Imperial (lbs/in)"}`}
            whileTap={{ scale: 0.9 }}
          >
            <Ruler className="w-4 h-4" />
          </motion.button>
          <motion.button
            onClick={() => {
              toggleTheme();
              const btn = document.querySelectorAll('.theme-toggle-btn');
              btn.forEach(b => b?.classList.add('toggled'));
              setTimeout(() => btn.forEach(b => b?.classList.remove('toggled')), 400);
            }}
            className="nav-toggle-btn theme-toggle-btn"
            aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
            whileTap={{ scale: 0.9 }}
          >
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </motion.button>
        </div>
      </div>

      <div className="relative flex flex-col min-h-screen" style={{ zIndex: 2 }}>
        <div className={`top-nav ${!showNav ? 'nav-hidden' : ''}`}>
          <nav className="mobile-nav">
            {brandLogos.lightMode && (
              <img 
                src={theme === 'dark' ? brandLogos.darkMode : brandLogos.lightMode}
                alt="LuggaGenius"
                className="mobile-nav-logo"
                onClick={handleLogoClick}
                style={{ transform: 'scaleY(1.15)' }}
              />
            )}
            <div className="mobile-nav-actions">
              <motion.button
                onClick={() => setMobileMenuOpen(true)}
                className="nav-toggle-btn"
                aria-label="Open menu"
                whileTap={{ scale: 0.9 }}
              >
                <Menu className="w-4 h-4" />
              </motion.button>
            </div>
          </nav>

          <nav className="desktop-nav">
            <div className="nav-tabs-center">
              <button
                className={`nav-tab ${activeTab === 'product' ? 'active' : ''}`}
                onClick={() => setActiveTab('product')}
              >
                Product
              </button>
              <button
                className={`nav-tab ${activeTab === 'about' ? 'active' : ''}`}
                onClick={() => setActiveTab('about')}
              >
                About
              </button>
              <button
                className={`nav-tab ${activeTab === 'corporate' ? 'active' : ''}`}
                onClick={() => setActiveTab('corporate')}
              >
                Corporate Solutions
              </button>
            </div>
            <div className="nav-toggle-group">
              <motion.button
                onClick={() => {
                  toggleUnitSystem();
                  const btn = document.querySelector('.desktop-nav .unit-toggle-btn');
                  btn?.classList.add('toggled');
                  setTimeout(() => btn?.classList.remove('toggled'), 400);
                }}
                className="nav-toggle-btn unit-toggle-btn"
                aria-label={`Switch to ${unitSystem === "metric" ? "imperial" : "metric"} units`}
                title={`Currently: ${unitSystem === "metric" ? "Metric (kg/cm)" : "Imperial (lbs/in)"}`}
                whileTap={{ scale: 0.9 }}
              >
                <Ruler className="w-4 h-4" />
              </motion.button>
              <motion.button
                onClick={() => {
                  toggleTheme();
                  const btn = document.querySelector('.desktop-nav .theme-toggle-btn');
                  btn?.classList.add('toggled');
                  setTimeout(() => btn?.classList.remove('toggled'), 400);
                }}
                className="nav-toggle-btn theme-toggle-btn"
                aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
                whileTap={{ scale: 0.9 }}
              >
                {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </motion.button>
            </div>
          </nav>
        </div>

        <section className="w-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6">
          <motion.header
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className={showResults ? "pt-3 pb-2 lg:pt-4 lg:pb-2" : "pt-6 pb-2 lg:pt-16 lg:pb-6"}
          >
            {showResults ? (
              <>
                {/* Desktop: Show compact logo when results are showing */}
                <div className="hidden lg:block">
                  <div className="flex items-center justify-center">
                    <div 
                      onClick={handleLogoClick}
                      className="logo-clickable cursor-pointer"
                    >
                      {brandLogos.lightMode && (
                        <img 
                          key={`results-light-${brandLogos.lightMode}`}
                          src={brandLogos.lightMode}
                          alt="Lugga Genius"
                          className="h-24 w-auto"
                          style={{ 
                            display: theme === 'dark' ? 'none' : 'block',
                            transform: 'scaleY(1.15)'
                          }}
                        />
                      )}
                      {brandLogos.darkMode && (
                        <img 
                          key={`results-dark-${brandLogos.darkMode}`}
                          src={brandLogos.darkMode}
                          alt="Lugga Genius"
                          className="h-24 w-auto"
                          style={{ 
                            display: theme === 'dark' ? 'block' : 'none',
                            transform: 'scaleY(1.15)'
                          }}
                        />
                      )}
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                {/* Desktop: Show logo */}
                <div className="hidden lg:block">
                  <div className="flex items-center justify-center mb-4">
                    <div 
                      onClick={handleLogoClick}
                      className="logo-clickable cursor-pointer"
                    >
                      {brandLogos.lightMode && (
                        <img 
                          key={`light-${brandLogos.lightMode}`}
                          src={brandLogos.lightMode}
                          alt="Lugga Genius"
                          className="h-24 sm:h-30 md:h-36 lg:h-42 w-auto"
                          style={{ 
                            display: theme === 'dark' ? 'none' : 'block',
                            transform: 'scaleY(1.15)'
                          }}
                        />
                      )}
                      {brandLogos.darkMode && (
                        <img 
                          key={`dark-${brandLogos.darkMode}`}
                          src={brandLogos.darkMode}
                          alt="Lugga Genius"
                          className="h-24 sm:h-30 md:h-36 lg:h-42 w-auto"
                          style={{ 
                            display: theme === 'dark' ? 'block' : 'none',
                            transform: 'scaleY(1.15)'
                          }}
                        />
                      )}
                    </div>
                  </div>
                </div>

                {/* Mobile: Show rotating text */}
                <div className="block lg:hidden">
                  <div className="flex items-center justify-center pt-4">
                    <RotatingText />
                  </div>
                </div>
              </>
            )}
          </motion.header>
        </section>

        {showResults && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="w-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6 mb-4"
          >
            <button
              onClick={handleReset}
              className="back-to-home-button"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Home</span>
            </button>
          </motion.div>
        )}

        <div 
          className={`${showResults ? "search-boxes-sticky" : ""} ${isMultiJourneyMode && showResults ? "multi-journey-compact" : ""}`}
          role="search" 
          aria-label="Flight search"
        >
          <div className="w-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6">
            <div className={isMultiJourneyMode && showResults ? "multi-journey-search-grid" : "grid gap-4 grid-cols-1"}>
              {journeys.map((journey, index) => (
                <div key={journey.id}>
                  <JourneySearchBox
                    journeyId={journey.id}
                    journeyIndex={index}
                    totalJourneys={journeys.length}
                    onAddAnotherFlight={handleAddAnotherFlight}
                    onReset={handleReset}
                    resetTrigger={resetTrigger}
                    isMultiJourney={isMultiJourneyMode}
                    showRemoveButton={isMultiJourneyMode && index === 1}
                    onRemove={handleRemoveSecondAirline}
                    onResultsChange={(hasResults, data) => {
                      setJourneys(prev => prev.map(j => 
                        j.id === journey.id 
                          ? { ...j, showResults: hasResults, ...data }
                          : j
                      ));
                    }}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        <section className="w-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6">
          <div className={shouldUseResultsLayout ? "pb-6 sm:pb-8" : "py-8 sm:py-10 md:py-12"}>
            <div className="text-center">
              <AnimatePresence>
                {!shouldUseResultsLayout && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.4 }}
                    className="mb-4 sm:mb-5 rotating-text-wrapper hidden lg:block"
                  >
                    <RotatingText />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </section>

        {showResults && (
          <motion.section
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full max-w-7xl mx-auto pb-12 sm:pb-16"
            role="region"
            aria-label="Flight baggage allowance results"
          >
            {isMultiJourneyMode ? (
              <div className="space-y-4 sm:space-y-6">
                {bothJourneysComplete && (
                  <div className="px-3 sm:px-4 md:px-6" role="complementary" aria-label="AI packing recommendations">
                    <GeniusPackerAI 
                      journey1={journeys[0]} 
                      journey2={journeys[1]} 
                    />
                  </div>
                )}
                <div className="px-3 sm:px-4 md:px-6">
                  <div className="results-grid-multi-container">
                    <div className="results-grid-multi">
                      {journeys.map((journey, index) => (
                        <div key={journey.id} className="journey-column">
                          {journey.showResults ? (
                            <>
                              <div className="journey-label-mobile" role="heading" aria-level="2">
                                <div className="journey-number" aria-label={`Flight ${index + 1}`}>
                                  {index + 1}
                                </div>
                                <div className="journey-airline">{journey.airline?.airline_name}</div>
                              </div>

                              {journey.airline?.enforcement_grade && (
                                <EnforcementWidget
                                  enforcementLevel={journey.airline.enforcement_grade}
                                  enforcementNotes={journey.airline.enforcement_notes}
                                  isCompact={true}
                                  hideBadge={true}
                                />
                              )}
                              
                              {ALLOWANCE_TYPES.map((type) => {
                                const displayName = TYPE_DISPLAY_NAMES[type];
                                const typeAllowances = (journey.allowances || []).filter(a => a.type === type);
                                
                                const anyJourneyHasType = journeys.some(j => 
                                  j.showResults && (j.allowances || []).some(a => a.type === type)
                                );
                                
                                if (!anyJourneyHasType) return null;

                                return (
                                  <div key={`journey${journey.id}-${type}`}>
                                    <AllowancePanel
                                      type={displayName}
                                      allowances={typeAllowances}
                                      purchaseUrl={journey.airline?.baggage_policy_url || journey.airline?.official_website_url || "#"}
                                      delay={0}
                                      airline={journey.airline}
                                      isMultiJourney={true}
                                    />
                                  </div>
                                );
                              })}
                            </>
                          ) : (
                            <div style={{ minHeight: '200px' }} />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="px-3 sm:px-4 md:px-6">
                {journeys[0]?.airline?.enforcement_grade && (
                  <div className="mb-6">
                    <EnforcementWidget
                      enforcementLevel={journeys[0].airline.enforcement_grade}
                      enforcementNotes={journeys[0].airline.enforcement_notes}
                      isCompact={false}
                      hideBadge={false}
                    />
                  </div>
                )}

                <div className="space-y-6">
                  {ALLOWANCE_TYPES.map((type) => {
                    const displayName = TYPE_DISPLAY_NAMES[type];
                    const typeAllowances = (journeys[0]?.allowances || []).filter(a => a.type === type);
                    const shouldHideWhenEmpty = type === 'personal_item' || type === 'special_items';
                    
                    if (shouldHideWhenEmpty && typeAllowances.length === 0) {
                      return null;
                    }

                    return (
                      <div key={type}>
                        <AllowancePanel
                          type={displayName}
                          allowances={typeAllowances}
                          purchaseUrl={journeys[0].airline?.baggage_policy_url || journeys[0].airline?.official_website_url || "#"}
                          delay={0}
                          airline={journeys[0].airline}
                          isMultiJourney={false}
                        />
                      </div>
                    );
                  })}
                </div>

                <div className="mt-6 sm:mt-8">
                  <ComparisonBanner
                    allowances={journeys[0]?.allowances || []}
                    airline={journeys[0]?.airline}
                    purchaseUrl={journeys[0]?.airline?.baggage_policy_url || journeys[0]?.airline?.official_website_url || "#"}
                  />
                </div>
              </div>
            )}
          </motion.section>
        )}

        {!shouldUseResultsLayout && (
          <>
            <motion.section
              layout
              transition={{ duration: 0.3, ease: "easeInOut" }}
              className="w-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6 pt-0 pb-8 sm:pb-12 md:pb-16 relative z-0"
            >
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.5 }}
                className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8 md:gap-12 max-w-5xl mx-auto"
              >
                <StatsCard
                  number={activeAirlinesCount > 0 ? activeAirlinesCount : 160}
                  label="Airlines Covered"
                  color="#8B7FFF"
                  delay={0.6}
                  suffix="+"
                />
                <StatsCard
                  displayValue="34K+"
                  label="Users Helped Worldwide"
                  color="#8B7FFF"
                  delay={0.7}
                />
                <StatsCard
                  displayValue="$2.0M+"
                  label="Excess Baggage Fines Avoided"
                  color="#8B7FFF"
                  delay={0.8}
                />
              </motion.div>
            </motion.section>

            <section className="w-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-8 sm:py-12 md:py-20 relative z-0">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="text-center mb-8 sm:mb-12 md:mb-16"
              >
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-3 sm:mb-4 px-4" style={{ color: 'var(--text-primary)' }}>
                  Why Travelers Love Us
                </h2>
                <p className="text-base sm:text-lg max-w-2xl mx-auto px-4" style={{ color: 'var(--text-secondary)' }}>
                  Real-time baggage policies, personalized recommendations, and smart alerts to save you money
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 md:gap-8">
                {[
                  { icon: Shield, title: "Accurate & Updated", description: "Live data refreshed daily from official airline sources. Always know the latest policies." },
                  { icon: Zap, title: "Lightning Fast", description: "Get instant results tailored to your ticket class, route, and loyalty status in seconds." },
                  { icon: Globe, title: "Global Coverage", description: "160+ airlines worldwide. From budget carriers to premium airlines, we've got you covered." }
                ].map((feature, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1, duration: 0.5 }}
                    className="feature-card rounded-xl sm:rounded-2xl p-5 sm:p-6 md:p-8"
                  >
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg sm:rounded-xl bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center mb-3 sm:mb-4">
                      <feature.icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3" style={{ color: 'var(--text-primary)' }}>
                      {feature.title}
                    </h3>
                    <p className="text-sm sm:text-base" style={{ color: 'var(--text-secondary)' }}>
                      {feature.description}
                    </p>
                  </motion.div>
                ))}
              </div>
            </section>

            <section className="w-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-8 sm:py-12 md:py-20 relative z-0">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="text-center mb-8 sm:mb-12 md:mb-16"
              >
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-3 sm:mb-4 px-4" style={{ color: 'var(--text-primary)' }}>
                  How It Works
                </h2>
                <p className="text-base sm:text-lg max-w-2xl mx-auto px-4" style={{ color: 'var(--text-secondary)' }}>
                  Three simple steps to stress-free packing
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 md:gap-8 max-w-5xl mx-auto">
                {[
                  { step: "1", title: "Search Your Airline", description: "Type your airline name and select from our comprehensive database" },
                  { step: "2", title: "Select Your Details", description: "Choose your ticket class, route type, and loyalty status" },
                  { step: "3", title: "Get Your Allowances", description: "View detailed baggage limits, dimensions, and upgrade options" }
                ].map((item, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1, duration: 0.5 }}
                    className="relative"
                  >
                    <div className="frosted-glass rounded-xl sm:rounded-2xl p-5 sm:p-6 md:p-8 text-center">
                      <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center text-xl sm:text-2xl font-bold text-white mx-auto mb-3 sm:mb-4">
                        {item.step}
                      </div>
                      <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3" style={{ color: 'var(--text-primary)' }}>
                        {item.title}
                      </h3>
                      <p className="text-sm sm:text-base" style={{ color: 'var(--text-secondary)' }}>
                        {item.description}
                      </p>
                    </div>
                    {idx < 2 && (
                      <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                        <ArrowRight className="w-8 h-8 text-[#6B36FF] opacity-30" />
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            </section>

            <section className="w-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-8 sm:py-12 md:py-20 relative z-0">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="frosted-glass rounded-2xl sm:rounded-3xl p-6 sm:p-8 md:p-12 text-center relative overflow-hidden"
              >
                <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, rgba(107, 54, 255, 0.1), rgba(217, 76, 255, 0.1))' }} />
                <div className="relative z-10">
                  <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold mb-3 sm:mb-4 px-4" style={{ color: 'var(--text-primary)' }}>
                    Ready to Pack Smart?
                  </h2>
                  <p className="text-base sm:text-lg mb-6 sm:mb-8 max-w-2xl mx-auto px-4" style={{ color: 'var(--text-secondary)' }}>
                    Join thousands of travelers who avoid excess baggage fees and airport stress
                  </p>
                  <button
                    onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                    className="inline-flex items-center gap-2 px-6 sm:px-8 py-3 sm:py-4 bg-gradient-to-r from-[#6B36FF] to-[#D94CFF] hover:opacity-90 text-white font-bold rounded-lg sm:rounded-xl transition-all text-base sm:text-lg"
                  >
                    Start Searching
                    <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
                  </button>
                </div>
              </motion.div>
            </section>
          </>
        )}

        <Footer />
      </div>
    </div>
  );
}

function JourneySearchBox({ 
  journeyId, 
  journeyIndex, 
  totalJourneys, 
  onAddAnotherFlight, 
  onReset, 
  resetTrigger,
  isMultiJourney,
  showRemoveButton,
  onRemove,
  onResultsChange 
}) {
  const [selectedAirline, setSelectedAirline] = useState(null);
  const [selectedFilters, setSelectedFilters] = useState({});
  const [allowances, setAllowances] = useState([]);
  const [showResults, setShowResults] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const filtersCompleteRef = useRef(false);

  const SUPABASE_URL = "https://ejwzyaipwxxnrkcmjelx.supabase.co";
  const SUPABASE_KEY = "sb_publishable_ZjLVjnPNTd0Eg4E3wUJqtA_kRb7a2Ki";

  useEffect(() => {
    const hasAirline = selectedAirline !== null;
    const hasFilters = Object.keys(selectedFilters).length > 0;
    
    if (hasAirline && hasFilters && !filtersCompleteRef.current) {
      filtersCompleteRef.current = true;
      fetchAllowances();
    }
    
    if (!hasAirline || !hasFilters) {
      filtersCompleteRef.current = false;
    }
  }, [selectedAirline, selectedFilters]);

  const fetchAllowances = async () => {
    if (!selectedAirline) return;
    
    setIsRefreshing(true);
    
    try {
      const airlineRes = await fetch(
        `${SUPABASE_URL}/rest/v1/airlines?id=eq.${selectedAirline.id}&select=*`,
        { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } }
      );
      const airlineData = await airlineRes.json();
      const fullAirline = Array.isArray(airlineData) && airlineData.length > 0 ? airlineData[0] : selectedAirline;
      
      const allowancesRes = await fetch(
        `${SUPABASE_URL}/rest/v1/allowances?airline_id=eq.${selectedAirline.id}&select=*`,
        { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } }
      );
      const allowancesData = await allowancesRes.json();
      const includedAllowances = Array.isArray(allowancesData) 
        ? allowancesData.filter(a => String(a.purchase_status).toLowerCase() === 'included')
        : [];

      let conditionsData = [];
      if (includedAllowances.length > 0) {
        const allowanceIds = includedAllowances.map(a => a.id).join(',');
        const conditionsRes = await fetch(
          `${SUPABASE_URL}/rest/v1/allowance_conditions?allowance_id=in.(${allowanceIds})&select=*`,
          { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } }
        );
        conditionsData = await conditionsRes.json();
      }
      
      const allowanceConditions = Array.isArray(conditionsData) ? conditionsData : [];

      const filtered = includedAllowances.filter(allowance => {
        const allowanceEntries = allowanceConditions.filter(ac => ac.allowance_id === allowance.id);
        
        if (allowanceEntries.length === 0) return true;

        const conditionsByAxis = new Map();
        for (const ac of allowanceEntries) {
          const axisId = String(ac.axis_id);
          const labelId = String(ac.label_id);
          if (!conditionsByAxis.has(axisId)) {
            conditionsByAxis.set(axisId, new Set());
          }
          conditionsByAxis.get(axisId).add(labelId);
        }

        for (const [selectedAxisId, selectedLabelId] of Object.entries(selectedFilters)) {
          const axisId = String(selectedAxisId);
          const labelId = String(selectedLabelId);
          
          if (conditionsByAxis.has(axisId)) {
            if (!conditionsByAxis.get(axisId).has(labelId)) {
              return false;
            }
          }
        }
        
        return true;
      });

      setAllowances(filtered);
      setIsRefreshing(false);
      setShowResults(true);
      
      onResultsChange(true, {
        airline: fullAirline,
        allowances: filtered,
        filters: selectedFilters
      });

    } catch (error) {
      console.error("Error fetching allowances:", error);
      setIsRefreshing(false);
    }
  };

  const handleAirlineSelect = (airline) => {
    setSelectedAirline(airline);
    setSelectedFilters({});
    filtersCompleteRef.current = false;
  };

  const handleFiltersComplete = (filters) => {
    setSelectedFilters(filters);
  };

  const handleBoxReset = () => {
    if (isMultiJourney) {
      setSelectedAirline(null);
      setSelectedFilters({});
      setShowResults(false);
      setAllowances([]);
      filtersCompleteRef.current = false;
      onResultsChange(false, {});
    } else {
      if (onReset) {
        onReset();
      }
    }
  };

  const canAddMore = totalJourneys < 4 && showResults && !isMultiJourney;

  return (
    <SearchBox 
      onAirlineSelect={handleAirlineSelect}
      onFiltersComplete={handleFiltersComplete}
      showResults={showResults}
      onReset={handleBoxReset}
      externalReset={resetTrigger}
      onAddLeg={canAddMore ? onAddAnotherFlight : null}
      showSubtleRemove={false}
      onRemove={showRemoveButton ? onRemove : undefined}
      showRemoveButton={showRemoveButton}
    />
  );
}
