import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useLocation, Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import AllowancePanel from "../components/allowances/AllowancePanel";
import EnforcementWidget from "../components/allowances/EnforcementWidget";
import LiveDataBadge from "../components/allowances/LiveDataBadge";
import ComparisonBanner from "../components/allowances/ComparisonBanner";
import StickyUpsellBar from "../components/allowances/StickyUpsellBar";

const SUPABASE_URL = "https://ejwzyaipwxxnrkcmjelx.supabase.co";
const SUPABASE_KEY = "sb_publishable_ZjLVjnPNTd0Eg4E3wUJqtA_kRb7a2Ki";

const ALLOWANCE_TYPES = ["personal_item", "carry_on", "checked", "special_items"];

const TYPE_DISPLAY_NAMES = {
  "personal_item": "Personal Item",
  "carry_on": "Carry-on",
  "checked": "Checked",
  "special_items": "Special Items"
};

export default function AirlineAllowances() {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const airlineName = searchParams.get("airline");

  const [airline, setAirline] = useState(null);
  const [allowances, setAllowances] = useState([]);
  const [allowanceConditions, setAllowanceConditions] = useState([]);
  const [selectedLabelIds, setSelectedLabelIds] = useState({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (airlineName) {
      // Extract filter params from URL
      const filterParams = {};
      searchParams.forEach((value, key) => {
        if (key.startsWith('filter_')) {
          const axisId = key.replace('filter_', '');
          filterParams[axisId] = value;
        }
      });
      setSelectedLabelIds(filterParams);
      
      fetchData();
    }
  }, [airlineName]);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Fetch airline details
      const airlineRes = await fetch(
        `${SUPABASE_URL}/rest/v1/airlines?airline_name=eq.${airlineName}&select=*`,
        {
          headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
        }
      );
      const airlineData = await airlineRes.json();
      const airlineInfo = Array.isArray(airlineData) && airlineData.length > 0 ? airlineData[0] : null;
      setAirline(airlineInfo);

      if (!airlineInfo) {
        setIsLoading(false);
        return;
      }

      // Fetch ALL allowances for this airline
      const allowancesRes = await fetch(
        `${SUPABASE_URL}/rest/v1/allowances?airline_id=eq.${airlineInfo.id}&select=*`,
        {
          headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
        }
      );
      const allowancesData = await allowancesRes.json();
      const allAllowances = Array.isArray(allowancesData) ? allowancesData : [];

      // FILTER: Only keep allowances with purchase_status = "Included"
      const includedAllowances = allAllowances.filter(a =>
        String(a.purchase_status).toLowerCase() === 'included'
      );
      setAllowances(includedAllowances);

      if (includedAllowances.length === 0) {
        setIsLoading(false);
        return;
      }

      // Fetch allowance_conditions junction table ONLY for included allowances
      const allowanceIds = includedAllowances.map(a => a.id).join(',');
      const conditionsRes = await fetch(
        `${SUPABASE_URL}/rest/v1/allowance_conditions?allowance_id=in.(${allowanceIds})&select=*`,
        {
          headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
        }
      );
      const conditionsData = await conditionsRes.json();
      const junctionData = Array.isArray(conditionsData) ? conditionsData : [];
      setAllowanceConditions(junctionData);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Get allowances that match current partial or full selection
  const getMatchingAllowances = (partialSelection) => {
    if (!partialSelection || Object.keys(partialSelection).length === 0) {
      return allowances;
    }

    return allowances.filter(allowance => {
      const entries = allowanceConditions.filter(ac => ac.allowance_id === allowance.id);

      if (entries.length === 0) {
        return true;
      }

      const byAxis = new Map();
      for (const ac of entries) {
        const axis = String(ac.axis_id);
        const label = String(ac.label_id);
        if (!byAxis.has(axis)) byAxis.set(axis, new Set());
        byAxis.get(axis).add(label);
      }

      return Object.entries(partialSelection).every(([selectedAxisId, selectedLabelId]) => {
        const currentAxisId = String(selectedAxisId);
        const currentLabelId = String(selectedLabelId);

        if (!byAxis.has(currentAxisId)) {
          return true;
        }

        return byAxis.get(currentAxisId).has(currentLabelId);
      });
    });
  };

  // Filter allowances by type and matching conditions
  const getFilteredAllowances = (type) => {
    const matchingAllowances = getMatchingAllowances(selectedLabelIds);
    return matchingAllowances.filter(a => a.type === type);
  };

  const getPurchaseUrl = () => {
    if (!airline) return "#";
    return airline.baggage_policy_url || airline.official_website_url || "#";
  };

  // Get all visible allowances for comparison banner
  const allVisibleAllowances = ALLOWANCE_TYPES.flatMap(type => getFilteredAllowances(type));

  // Generate gradient style based on airline colors
  const getAirlineGradientStyle = () => {
    if (airline?.primary_color && airline?.secondary_color) {
      return {
        background: `linear-gradient(135deg, ${airline.primary_color} 0%, ${airline.secondary_color} 100%)`,
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent',
        backgroundClip: 'text',
      };
    }
    return {};
  };

  const useCustomGradient = airline?.primary_color && airline?.secondary_color;

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F8F8F8]">
      <style>{`
        .frosted-glass {
          background: rgba(255, 255, 255, 0.03);
          backdrop-filter: blur(60px);
          -webkit-backdrop-filter: blur(60px);
          border: 1px solid rgba(255, 255, 255, 0.08);
        }

        .frosted-glass-light {
          background: rgba(255, 255, 255, 0.05);
          backdrop-filter: blur(40px);
          -webkit-backdrop-filter: blur(40px);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        @keyframes hue-flow {
          0% { filter: hue-rotate(0deg); }
          100% { filter: hue-rotate(30deg); }
        }

        .text-gradient {
          background: linear-gradient(135deg, #6B36FF 0%, #D94CFF 50%, #D2FF4D 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: hue-flow 8s ease-in-out infinite alternate;
        }
      `}</style>

      {/* Ambient background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div
          className="absolute top-20 right-20 w-[500px] h-[500px] rounded-full blur-[120px] opacity-20"
          style={{ background: 'radial-gradient(circle, #6B36FF 0%, transparent 70%)' }}
        />
        <div
          className="absolute bottom-20 left-20 w-[600px] h-[600px] rounded-full blur-[140px] opacity-15"
          style={{ background: 'radial-gradient(circle, #D94CFF 0%, transparent 70%)' }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <Link to={createPageUrl("Home")}>
            <Button variant="ghost" className="text-[#C8CDD3] hover:text-[#F8F8F8] hover:bg-white/5 mb-6">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Search
            </Button>
          </Link>

          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-2">
                <span 
                  className={useCustomGradient ? '' : 'text-gradient'}
                  style={useCustomGradient ? getAirlineGradientStyle() : {}}
                >
                  {airlineName}
                </span>
              </h1>
              <p className="text-xl text-[#C8CDD3]">Baggage Allowances</p>
            </div>
            {airline?.last_refreshed_at && (
              <LiveDataBadge lastRefreshedAt={airline.last_refreshed_at} />
            )}
          </div>
        </motion.div>

        {/* Enforcement Widget */}
        {airline && airline.enforcement_grade && !isLoading && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mb-8"
          >
            <EnforcementWidget
              enforcementLevel={airline.enforcement_grade}
              enforcementNotes={airline.enforcement_notes}
            />
          </motion.div>
        )}

        {/* Allowances by Type - Always show when data is loaded */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-12 h-12 border-4 border-[#6B36FF] border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <>
            <div className="space-y-8">
              {ALLOWANCE_TYPES.map((type, index) => {
                const typeAllowances = getFilteredAllowances(type);
                const displayName = TYPE_DISPLAY_NAMES[type];

                // Only show personal_item and special_items if they have allowances
                const shouldHideWhenEmpty = type === 'personal_item' || type === 'special_items';
                if (shouldHideWhenEmpty && typeAllowances.length === 0) {
                  return null;
                }

                return (
                  <AllowancePanel
                    key={type}
                    type={displayName}
                    allowances={typeAllowances}
                    purchaseUrl={getPurchaseUrl()}
                    delay={0.3 + index * 0.1}
                    airline={airline}
                  />
                );
              })}
            </div>

            {/* TIER 2: Comparison Banner - Shows after all allowances */}
            <ComparisonBanner
              allowances={allVisibleAllowances}
              airline={airline}
              purchaseUrl={getPurchaseUrl()}
            />
          </>
        )}
      </div>

      {/* TIER 3: Sticky Upsell Bar - Only show when allowances are visible */}
      {!isLoading && (
        <StickyUpsellBar
          airline={airline}
          purchaseUrl={getPurchaseUrl()}
          allowances={allVisibleAllowances}
        />
      )}
    </div>
  );
}