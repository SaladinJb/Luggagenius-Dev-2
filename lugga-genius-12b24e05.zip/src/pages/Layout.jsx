
import React from "react";
import ThemeProvider from "./components/ThemeProvider";
import UnitSystemProvider from "./components/UnitSystemProvider";

export default function Layout({ children, currentPageName }) {
  return (
    <ThemeProvider>
      <UnitSystemProvider>
        {children}
      </UnitSystemProvider>
    </ThemeProvider>
  );
}
