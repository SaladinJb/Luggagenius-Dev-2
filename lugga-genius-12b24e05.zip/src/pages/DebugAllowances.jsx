
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, Database } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";

const SUPABASE_URL = "https://ejwzyaipwxxnrkcmjelx.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVqd3p5YWlwd3h4bnJrY21qZWx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTkwODA0OTIsImV4cCI6MjA3NDY1NjQ5Mn0.k9N6myh_-5HlmjnUh80dXGLQLehrxfsoilL0R37JLT0";

export default function DebugAllowances() {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDebugData();
  }, []);

  const fetchDebugData = async () => {
    setIsLoading(true);
    try {
      // 1. Fetch Air France airline
      const airlineRes = await fetch(
        `${SUPABASE_URL}/rest/v1/airlines?airline_name=eq.Air France&select=*`,
        {
          headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
        }
      );
      const airlineData = await airlineRes.json();
      const airline = airlineData[0];

      if (!airline) {
        setData({ error: "Air France not found" });
        setIsLoading(false);
        return;
      }

      // 2. Fetch allowances
      const allowancesRes = await fetch(
        `${SUPABASE_URL}/rest/v1/allowances?airline_id=eq.${airline.id}&select=*`,
        {
          headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
        }
      );
      const allowances = await allowancesRes.json();

      // 3. Fetch condition axes
      const axesRes = await fetch(
        `${SUPABASE_URL}/rest/v1/condition_axes?airline_id=eq.${airline.id}&select=*`,
        {
          headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
        }
      );
      const axes = await axesRes.json();

      // 4. Fetch condition labels
      if (axes.length > 0) {
        const axisIds = axes.map(a => a.id).join(',');
        const labelsRes = await fetch(
          `${SUPABASE_URL}/rest/v1/condition_labels?axis_id=in.(${axisIds})&select=*`,
          {
            headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
          }
        );
        const labels = await labelsRes.json();

        // 5. Fetch junction table
        if (allowances.length > 0) {
          const allowanceIds = allowances.map(a => a.id).join(',');
          const junctionRes = await fetch(
            `${SUPABASE_URL}/rest/v1/allowance_conditions?allowance_id=in.(${allowanceIds})&select=*`,
            {
              headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }
            }
          );
          const junction = await junctionRes.json();

          // Build enriched data
          const enrichedAllowances = allowances.map(allowance => {
            const conditions = junction
              .filter(j => j.allowance_id === allowance.id)
              .map(j => {
                const axis = axes.find(a => a.id === j.axis_id);
                const label = labels.find(l => l.id === j.label_id);
                return {
                  axis_name: axis?.axis_name || 'Unknown',
                  label: label?.label || 'Unknown',
                  axis_id: j.axis_id,
                  label_id: j.label_id
                };
              });

            return {
              ...allowance,
              conditions
            };
          });

          setData({
            airline,
            allowances: enrichedAllowances,
            axes,
            labels,
            junction
          });
        }
      }
    } catch (error) {
      console.error("Error fetching debug data:", error);
      setData({ error: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] text-[#F8F8F8] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-[#6B36FF] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (data?.error) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] text-[#F8F8F8] p-6">
        <div className="max-w-4xl mx-auto">
          <p className="text-red-400">Error: {data.error}</p>
        </div>
      </div>
    );
  }

  const groupedByType = data?.allowances.reduce((acc, allowance) => {
    if (!acc[allowance.type]) acc[allowance.type] = [];
    acc[allowance.type].push(allowance);
    return acc;
  }, {});

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F8F8F8] p-6">
      <style>{`
        .debug-table {
          width: 100%;
          border-collapse: collapse;
          background: rgba(255, 255, 255, 0.03);
          border-radius: 12px;
          overflow: hidden;
        }
        .debug-table th {
          background: rgba(107, 54, 255, 0.2);
          padding: 12px;
          text-align: left;
          font-weight: 600;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .debug-table td {
          padding: 12px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        .debug-table tr:hover {
          background: rgba(255, 255, 255, 0.05);
        }
      `}</style>

      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Link to={createPageUrl("Home")}>
            <Button variant="ghost" className="text-[#C8CDD3] hover:text-[#F8F8F8] hover:bg-white/5 mb-6">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Home
            </Button>
          </Link>

          <div className="flex items-center gap-3 mb-6">
            <Database className="w-8 h-8 text-[#6B36FF]" />
            <h1 className="text-4xl font-bold">Debug: Air France Allowances</h1>
          </div>
        </motion.div>

        {/* Summary Stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <div className="bg-white/5 rounded-xl p-4">
            <p className="text-[#C8CDD3] text-sm">Total Allowances</p>
            <p className="text-3xl font-bold text-[#6B36FF]">{data?.allowances.length || 0}</p>
          </div>
          <div className="bg-white/5 rounded-xl p-4">
            <p className="text-[#C8CDD3] text-sm">Condition Axes</p>
            <p className="text-3xl font-bold text-[#D94CFF]">{data?.axes.length || 0}</p>
          </div>
          <div className="bg-white/5 rounded-xl p-4">
            <p className="text-[#C8CDD3] text-sm">Condition Labels</p>
            <p className="text-3xl font-bold text-[#D2FF4D]">{data?.labels.length || 0}</p>
          </div>
          <div className="bg-white/5 rounded-xl p-4">
            <p className="text-[#C8CDD3] text-sm">Junction Entries</p>
            <p className="text-3xl font-bold text-[#6B36FF]">{data?.junction.length || 0}</p>
          </div>
        </div>

        {/* Allowances by Type */}
        {Object.entries(groupedByType || {}).map(([type, allowances]) => (
          <motion.div
            key={type}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h2 className="text-2xl font-bold mb-4 text-[#6B36FF]">{type} ({allowances.length})</h2>
            <div className="overflow-x-auto">
              <table className="debug-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Purchase Status</th>
                    <th>Pieces</th>
                    <th>Weight (kg)</th>
                    <th>Dimensions</th>
                    <th>Conditions</th>
                  </tr>
                </thead>
                <tbody>
                  {allowances.map(allowance => (
                    <tr key={allowance.id}>
                      <td className="font-mono text-xs">{allowance.id.substring(0, 8)}...</td>
                      <td>
                        <span className={`px-2 py-1 rounded text-xs ${
                          allowance.purchase_status === 'Included' 
                            ? 'bg-green-500/20 text-green-400' 
                            : 'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {allowance.purchase_status}
                        </span>
                      </td>
                      <td>{allowance.pieces_allowed || '-'}</td>
                      <td>{allowance.weight_limit_kg || '-'}</td>
                      <td className="text-sm">
                        {allowance.dim_length_cm && `L:${allowance.dim_length_cm} `}
                        {allowance.dim_width_cm && `W:${allowance.dim_width_cm} `}
                        {allowance.dim_height_cm && `H:${allowance.dim_height_cm}`}
                        {!allowance.dim_length_cm && !allowance.dim_width_cm && !allowance.dim_height_cm && '-'}
                      </td>
                      <td>
                        {allowance.conditions.length === 0 ? (
                          <span className="text-[#C8CDD3] italic">No conditions (applies to all)</span>
                        ) : (
                          <div className="space-y-1">
                            {allowance.conditions.map((cond, idx) => (
                              <div key={idx} className="text-sm">
                                <span className="text-[#6B36FF]">{cond.axis_name}</span>
                                {': '}
                                <span className="text-[#F8F8F8]">{cond.label}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        ))}

        {/* Raw Data Dumps */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <details className="bg-white/5 rounded-xl p-4">
            <summary className="cursor-pointer font-semibold text-[#6B36FF]">Condition Axes</summary>
            <pre className="mt-4 text-xs overflow-x-auto">{JSON.stringify(data?.axes, null, 2)}</pre>
          </details>

          <details className="bg-white/5 rounded-xl p-4">
            <summary className="cursor-pointer font-semibold text-[#D94CFF]">Condition Labels</summary>
            <pre className="mt-4 text-xs overflow-x-auto">{JSON.stringify(data?.labels, null, 2)}</pre>
          </details>

          <details className="bg-white/5 rounded-xl p-4">
            <summary className="cursor-pointer font-semibold text-[#D2FF4D]">Junction Table</summary>
            <pre className="mt-4 text-xs overflow-x-auto">{JSON.stringify(data?.junction, null, 2)}</pre>
          </details>
        </motion.div>
      </div>
    </div>
  );
}
