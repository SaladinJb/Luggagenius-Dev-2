import React, { createContext, useContext, useState, useEffect } from "react";

const UnitSystemContext = createContext();

export const useUnitSystem = () => {
  const context = useContext(UnitSystemContext);
  if (!context) {
    throw new Error("useUnitSystem must be used within UnitSystemProvider");
  }
  return context;
};

export default function UnitSystemProvider({ children }) {
  const [unitSystem, setUnitSystem] = useState("metric");

  useEffect(() => {
    const savedUnit = localStorage.getItem("unit-system");
    if (savedUnit) {
      setUnitSystem(savedUnit);
    }
  }, []);

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => {
      const newUnit = prev === "metric" ? "imperial" : "metric";
      localStorage.setItem("unit-system", newUnit);
      return newUnit;
    });
  };

  const convertWeight = (kg) => {
    if (!kg) return null;
    if (unitSystem === "imperial") {
      return Math.floor(kg * 2.20462);
    }
    return kg;
  };

  const convertDimension = (cm) => {
    if (!cm) return null;
    if (unitSystem === "imperial") {
      return Math.floor(cm * 0.393701);
    }
    return cm;
  };

  const getWeightUnit = () => unitSystem === "metric" ? "kg" : "lbs";
  const getDimensionUnit = () => unitSystem === "metric" ? "cm" : "in";

  const formatWeight = (kg) => {
    const converted = convertWeight(kg);
    return converted ? `${converted} ${getWeightUnit()}` : "Not specified";
  };

  const formatDimension = (cm) => {
    const converted = convertDimension(cm);
    return converted ? `${converted} ${getDimensionUnit()}` : null;
  };

  const formatDimensions = (length, width, height, dimensionType) => {
    if (dimensionType === "linear" || dimensionType === "Linear") {
      const linearDim = length || width || height;
      const converted = convertDimension(linearDim);
      return converted ? `${converted} ${getDimensionUnit()} (linear)` : "Not specified";
    }
    
    const dims = [];
    if (length) dims.push(`L: ${convertDimension(length)}${getDimensionUnit()}`);
    if (width) dims.push(`W: ${convertDimension(width)}${getDimensionUnit()}`);
    if (height) dims.push(`H: ${convertDimension(height)}${getDimensionUnit()}`);
    
    return dims.length > 0 ? dims.join(" × ") : "Not specified";
  };

  return (
    <UnitSystemContext.Provider
      value={{
        unitSystem,
        toggleUnitSystem,
        convertWeight,
        convertDimension,
        getWeightUnit,
        getDimensionUnit,
        formatWeight,
        formatDimension,
        formatDimensions,
      }}
    >
      {children}
    </UnitSystemContext.Provider>
  );
}