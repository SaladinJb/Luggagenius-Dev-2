import React from "react";
import { motion } from "framer-motion";
import { Ruler } from "lucide-react";
import { useUnitSystem } from "./UnitSystemProvider";

export default function UnitSystemToggle() {
  const { unitSystem, toggleUnitSystem } = useUnitSystem();

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={toggleUnitSystem}
      className="unit-toggle-button"
      aria-label={`Switch to ${unitSystem === "metric" ? "imperial" : "metric"} units`}
      title={`Currently: ${unitSystem === "metric" ? "Metric (kg/cm)" : "Imperial (lbs/in)"}`}
    >
      <Ruler className="w-4 h-4" />
      <span className="text-xs font-medium">
        {unitSystem === "metric" ? "kg" : "lb"}
      </span>
    </motion.button>
  );
}