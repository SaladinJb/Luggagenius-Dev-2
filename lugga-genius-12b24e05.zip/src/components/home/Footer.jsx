import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plane, Mail, MessageSquare } from "lucide-react";

const SUPABASE_URL = "https://ejwzyaipwxxnrkcmjelx.supabase.co";
const SUPABASE_KEY = "sb_publishable_ZjLVjnPNTd0Eg4E3wUJqtA_kRb7a2Ki";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  const [footerLogo, setFooterLogo] = useState(null);

  useEffect(() => {
    fetchFooterLogo();
  }, []);

  const fetchFooterLogo = async () => {
    try {
      const cacheBuster = `?t=${Date.now()}`;
      
      const response = await fetch(
        `${SUPABASE_URL}/rest/v1/brand_assets?variant=eq.mono_white&file_type=eq.svg&active=eq.true&select=public_url`,
        { 
          headers: { 
            apikey: SUPABASE_KEY, 
            Authorization: `Bearer ${SUPABASE_KEY}`,
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache'
          } 
        }
      );
      const assets = await response.json();
      
      if (Array.isArray(assets) && assets.length > 0 && assets[0].public_url) {
        setFooterLogo(`${assets[0].public_url}${cacheBuster}`);
      }
    } catch (error) {
      console.error("Error fetching footer logo:", error);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative z-10 bg-[#0A0A0A] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 sm:gap-12">
          {/* Brand Column */}
          <div className="md:col-span-1">
            <div 
              onClick={scrollToTop}
              className="flex items-center gap-2 mb-4 cursor-pointer hover:opacity-80 transition-opacity w-fit"
            >
              {footerLogo ? (
                <img 
                  key={footerLogo}
                  src={footerLogo} 
                  alt="LuggaGenius" 
                  className="h-7 w-auto"
                  style={{ transform: 'scaleY(1.15)' }}
                />
              ) : (
                <>
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center">
                    <Plane className="w-4 h-4 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-gradient">LuggaGenius</h3>
                </>
              )}
            </div>
            <p className="text-sm text-[#C8CDD3] mb-4">
              Your smart companion for stress-free travel. Know your baggage allowances before you fly.
            </p>
            <div className="flex gap-3">
              <a
                href="mailto:hello@luggagenius.com"
                className="w-9 h-9 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center transition-colors"
                aria-label="Email us"
              >
                <Mail className="w-4 h-4 text-[#C8CDD3]" />
              </a>
              <a
                href="#contact"
                className="w-9 h-9 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center transition-colors"
                aria-label="Contact us"
              >
                <MessageSquare className="w-4 h-4 text-[#C8CDD3]" />
              </a>
            </div>
          </div>

          {/* Product Column */}
          <div>
            <h4 className="text-sm font-semibold text-[#F8F8F8] mb-4">Product</h4>
            <ul className="space-y-3">
              <li>
                <Link
                  to={createPageUrl("Home")}
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  Search Allowances
                </Link>
              </li>
              <li>
                <a
                  href="#features"
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  Features
                </a>
              </li>
              <li>
                <a
                  href="#how-it-works"
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  How It Works
                </a>
              </li>
              <li>
                <a
                  href="#airlines"
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  Supported Airlines
                </a>
              </li>
            </ul>
          </div>

          {/* Company Column */}
          <div>
            <h4 className="text-sm font-semibold text-[#F8F8F8] mb-4">Company</h4>
            <ul className="space-y-3">
              <li>
                <a
                  href="#about"
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  About Us
                </a>
              </li>
              <li>
                <Link
                  to={createPageUrl("Contact")}
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  Contact
                </Link>
              </li>
              <li>
                <a
                  href="#blog"
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  Blog
                </a>
              </li>
              <li>
                <a
                  href="#careers"
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  Careers
                </a>
              </li>
            </ul>
          </div>

          {/* Legal Column */}
          <div>
            <h4 className="text-sm font-semibold text-[#F8F8F8] mb-4">Legal</h4>
            <ul className="space-y-3">
              <li>
                <a
                  href="#privacy"
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  Privacy Policy
                </a>
              </li>
              <li>
                <a
                  href="#terms"
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  Terms of Service
                </a>
              </li>
              <li>
                <a
                  href="#cookies"
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  Cookie Policy
                </a>
              </li>
              <li>
                <a
                  href="#disclaimer"
                  className="text-sm text-[#C8CDD3] hover:text-[#6B36FF] transition-colors"
                >
                  Disclaimer
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-white/5">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-[#C8CDD3] text-center sm:text-left">
              © {currentYear} LuggaGenius. All rights reserved.
            </p>
            <p className="text-xs text-[#C8CDD3] text-center sm:text-right">
              Data refreshed daily • Not affiliated with airlines
            </p>
          </div>
        </div>
      </div>

      <style jsx>{`
        .text-gradient {
          background: linear-gradient(135deg, #6B36FF 0%, #D94CFF 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
      `}</style>
    </footer>
  );
}