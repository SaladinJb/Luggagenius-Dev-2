import React from "react";
import FloatingObject from "./FloatingObject";

const objects = [
  {
    src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ea2a47e606ea8412b24e05/3fa439eee_20250915_2019_WhimsicalColorfulAirplane_remix_01k579hmb0f6g91h7qa9g0pa47.png",
    alt: "Plane",
    side: "right",
    verticalPosition: "10%",
    size: 450,
    rotate: 25,
    floatDuration: 7,
    floatDistance: 30
  },
  {
    src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ea2a47e606ea8412b24e05/117875f13_20250917_1941_GlowingTapeMeasure_remix_01k5cc66arfa2bp4b2bdznjadn.png",
    alt: "Measuring Tape",
    side: "right",
    verticalPosition: "65%",
    size: 280,
    rotate: -15,
    floatDuration: 5.5,
    floatDistance: 20
  },
  {
    src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ea2a47e606ea8412b24e05/670593ce6_20250915_2001_Floating3DSuitcase_remix_01k578gw3bfmxtp31398xccmfk.png",
    alt: "Luggage",
    side: "left",
    verticalPosition: "20%",
    size: 380,
    rotate: 10,
    floatDuration: 6,
    floatDistance: 25
  },
  {
    src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ea2a47e606ea8412b24e05/f92b4262d_20250916_0003_TurquoiseTimerHook_remix_01k57pc44tektvkz90e52b1nv5.png",
    alt: "Weight Scale",
    side: "left",
    verticalPosition: "70%",
    size: 320,
    rotate: -20,
    floatDuration: 6.5,
    floatDistance: 22
  }
];

export default function FloatingObjects() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {objects.map((obj, index) => (
        <FloatingObject
          key={index}
          obj={obj}
          index={index}
        />
      ))}
    </div>
  );
}