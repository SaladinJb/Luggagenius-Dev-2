import React, { useEffect, useState } from "react";
import { motion, useInView } from "framer-motion";

export default function StatsCard({ number, displayValue, label, color, delay, prefix = "", suffix = "" }) {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true });
  const [displayNumber, setDisplayNumber] = useState(null);

  useEffect(() => {
    if (isInView && typeof number === 'number' && !displayValue) {
      let startTime;
      const duration = 2000;
      const targetNumber = number;
      const startNumber = Math.max(1, Math.floor(targetNumber * 0.5));

      const animate = (timestamp) => {
        if (!startTime) startTime = timestamp;
        const progress = Math.min((timestamp - startTime) / duration, 1);
        
        const easeOutQuart = 1 - Math.pow(1 - progress, 4);
        const currentNumber = Math.floor(startNumber + (easeOutQuart * (targetNumber - startNumber)));
        
        setDisplayNumber(currentNumber);

        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };

      requestAnimationFrame(animate);
    }
  }, [isInView, number, displayValue]);

  const getDisplayText = () => {
    if (displayValue) {
      return displayValue;
    }
    
    if (displayNumber === null) {
      return '';
    }

    return `${prefix}${displayNumber}${suffix}`;
  };

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay }}
      className="frosted-glass rounded-3xl p-8 text-center relative overflow-hidden group"
    >
      <style>{`
        @keyframes subtle-hue {
          0%, 100% { filter: hue-rotate(0deg) brightness(1); }
          50% { filter: hue-rotate(15deg) brightness(1.1); }
        }

        .stat-card-glow {
          position: absolute;
          inset: 0;
          opacity: 0;
          transition: opacity 0.5s ease;
          pointer-events: none;
        }
        
        .group:hover .stat-card-glow {
          opacity: 1;
        }

        .animated-number {
          animation: subtle-hue 6s ease-in-out infinite;
        }
      `}</style>

      {/* Glow effect on hover */}
      <div 
        className="stat-card-glow"
        style={{ 
          background: `radial-gradient(circle at center, ${color}20 0%, transparent 70%)`,
          filter: 'blur(40px)'
        }}
      />

      {/* Content */}
      <div className="relative z-10">
        <motion.h2
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: delay + 0.2 }}
          className="text-5xl md:text-6xl font-bold mb-4 animated-number"
          style={{ color }}
        >
          {getDisplayText()}
        </motion.h2>
        <p className="text-lg tracking-wide" style={{ color: 'var(--text-secondary)' }}>
          {label}
        </p>
      </div>

      {/* Bottom edge glow */}
      <div
        className="absolute bottom-0 left-0 right-0 h-1"
        style={{ 
          background: `linear-gradient(90deg, transparent 0%, ${color} 50%, transparent 100%)`,
          opacity: 0.5
        }}
      />
    </motion.div>
  );
}