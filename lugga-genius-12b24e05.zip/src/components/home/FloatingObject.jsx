import React from "react";
import { motion } from "framer-motion";

export default function FloatingObject({ obj, index }) {
  const isLeft = obj.side === "left";
  
  // Desktop: 80% visible (20% hidden) - offset is 20% of size
  // Mobile: 50% visible (50% hidden) - offset is 50% of size
  const desktopOffset = obj.size * 0.2;
  const mobileOffset = obj.size * 0.5;

  return (
    <>
      <style>{`
        .floating-object-${index} {
          left: ${isLeft ? `-${mobileOffset}px` : 'auto'};
          right: ${!isLeft ? `-${mobileOffset}px` : 'auto'};
        }
        
        @media (min-width: 1024px) {
          .floating-object-${index} {
            left: ${isLeft ? `-${desktopOffset}px` : 'auto'};
            right: ${!isLeft ? `-${desktopOffset}px` : 'auto'};
          }
        }
      `}</style>
      
      <motion.div
        className={`absolute floating-object-${index}`}
        style={{
          top: obj.verticalPosition,
          transform: 'translateY(-50%)',
        }}
        initial={{ opacity: 0, scale: 0.8, rotate: obj.rotate, x: isLeft ? -100 : 100 }}
        animate={{
          opacity: 1,
          scale: 1,
          rotate: obj.rotate,
          x: 0,
          y: [0, -obj.floatDistance, 0],
        }}
        transition={{
          opacity: { duration: 1, delay: index * 0.15 },
          scale: { duration: 1, delay: index * 0.15 },
          x: { duration: 1, delay: index * 0.15 },
          rotate: { duration: 1, delay: index * 0.15 },
          y: {
            duration: obj.floatDuration,
            repeat: Infinity,
            ease: "easeInOut",
            delay: index * 0.3,
          }
        }}
      >
        <img
          src={obj.src}
          alt={obj.alt}
          style={{
            width: `${obj.size}px`,
            height: `${obj.size}px`,
            objectFit: "contain",
            userSelect: "none",
          }}
          draggable={false}
        />
      </motion.div>
    </>
  );
}