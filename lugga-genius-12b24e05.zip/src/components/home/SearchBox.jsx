
import React, { useState, useEffect, useRef, useMemo } from "react";
import { useLocation, Link } from "react-router-dom";
import { Search, Plane, X, Edit2, Loader2, Plus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { createPageUrl } from "@/utils";
import ConditionFilters from "../allowances/ConditionFilters";
import LiveDataBadge from "../allowances/LiveDataBadge";

const SUPABASE_URL = "https://ejwzyaipwxxnrkcmjelx.supabase.co";
const SUPABASE_KEY = "sb_publishable_ZjLVjnPNTd0Eg4E3wUJqtA_kRb7a2Ki";

const formatLabel = (text) => {
  if (!text) return '';
  return text
    .replace(/_/g, ' ')
    .toLowerCase()
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

const fetchAirlinesWithAllowances = async () => {
  console.log("🔍 Fetching airlines...");
  try {
    const [airlinesRes, allowancesRes] = await Promise.all([
      fetch(
        `${SUPABASE_URL}/rest/v1/airlines?active=eq.true&select=id,airline_name,logo_url`,
        {
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`,
          },
        }
      ),
      fetch(
        `${SUPABASE_URL}/rest/v1/allowances?select=airline_id`,
        {
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${SUPABASE_KEY}`,
          },
        }
      )
    ]);

    console.log("📊 Airlines response status:", airlinesRes.status);
    console.log("📊 Allowances response status:", allowancesRes.status);

    const airlines = await airlinesRes.json();
    const allowances = await allowancesRes.json();

    console.log("✅ Airlines fetched:", airlines.length);
    console.log("✅ Allowances fetched:", allowances.length);

    const airlinesWithAllowances = new Set(
      (Array.isArray(allowances) ? allowances : []).map(a => a.airline_id)
    );

    const filteredAirlines = (Array.isArray(airlines) ? airlines : [])
      .filter(airline => airlinesWithAllowances.has(airline.id))
      .sort((a, b) => a.airline_name.localeCompare(b.airline_name));

    console.log("✨ Filtered airlines:", filteredAirlines.length);

    return filteredAirlines;
  } catch (error) {
    console.error("❌ Error fetching airlines:", error);
    throw error;
  }
};

export default function SearchBox({ onAirlineSelect, onFiltersComplete, showResults, onReset, externalReset, onAddLeg, showSubtleRemove, forceCompact = false }) {
  const location = useLocation();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  
  const [selectedAirline, setSelectedAirline] = useState(null);
  const [conditionAxes, setConditionAxes] = useState([]);
  const [conditionLabels, setConditionLabels] = useState([]);
  const [allowances, setAllowances] = useState([]);
  const [allowanceConditions, setAllowanceConditions] = useState([]);
  const [selectedLabelIds, setSelectedLabelIds] = useState({});
  const [isEditingAirline, setIsEditingAirline] = useState(false);
  const [editingAxisId, setEditingAxisId] = useState(null);
  const [isHoveringAirline, setIsHoveringAirline] = useState(false);

  const searchTimeoutRef = useRef(null);

  const isHomePage = location.pathname === '/' || location.pathname.toLowerCase().includes('home');

  const { data: airlines = [], isLoading, error } = useQuery({
    queryKey: ['airlines-with-allowances'],
    queryFn: fetchAirlinesWithAllowances,
    staleTime: 5 * 60 * 1000,
    cacheTime: 10 * 60 * 1000,
    enabled: isHomePage,
  });

  const filteredAirlines = useMemo(() => {
    console.log("🔎 Filtering airlines. Query:", searchQuery, "Airlines available:", airlines.length);
    
    if (!searchQuery || searchQuery.length === 0) {
      console.log("⚠️ No search query");
      return [];
    }
    
    const query = searchQuery.toLowerCase().trim();
    if (query.length < 2) {
      console.log("⚠️ Query too short:", query);
      return [];
    }
    
    const filtered = airlines.filter(airline => 
      airline.airline_name.toLowerCase().includes(query)
    ).slice(0, 10);
    
    console.log("✅ Filtered results:", filtered.length, filtered.map(a => a.airline_name));
    
    return filtered;
  }, [searchQuery, airlines]);

  const hasSearchQuery = searchQuery.length >= 2;
  const noResultsFound = hasSearchQuery && filteredAirlines.length === 0 && !isLoading;

  const allFiltersComplete = Boolean(
    selectedAirline && 
    conditionAxes.length > 0 && 
    Object.keys(selectedLabelIds).length === conditionAxes.length &&
    conditionAxes.every(axis => selectedLabelIds[axis.id] !== undefined)
  );

  useEffect(() => {
    if (externalReset) {
      setSearchQuery("");
      setSelectedAirline(null);
      setConditionAxes([]);
      setConditionLabels([]);
      setSelectedLabelIds({});
      setShowDropdown(false);
      setEditingAxisId(null);
      setIsEditingAirline(false);
    }
  }, [externalReset]);

  useEffect(() => {
    if (!selectedAirline || conditionAxes.length === 0) return;
    
    const allSelected = conditionAxes.every(axis => selectedLabelIds[axis.id] !== undefined);
    
    if (allSelected && onFiltersComplete) {
      onFiltersComplete(selectedLabelIds);
    }
  }, [selectedLabelIds, conditionAxes, selectedAirline, onFiltersComplete]);

  useEffect(() => {
    if (!isHomePage) return;
    
    if (selectedAirline && !isEditingAirline) {
      setShowDropdown(false);
      return;
    }
    
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    if (searchQuery.length >= 2) {
      searchTimeoutRef.current = setTimeout(() => {
        setShowDropdown(filteredAirlines.length > 0 || noResultsFound);
      }, 150);
    } else {
      setShowDropdown(false);
    }

    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
    };
  }, [searchQuery, filteredAirlines.length, selectedAirline, isHomePage, isEditingAirline, noResultsFound]);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAirlineSelect = async (airline) => {
    if (!isHomePage) return;
    
    setSearchQuery(airline.airline_name);
    setShowDropdown(false);
    setSelectedAirline(airline);
    setSelectedLabelIds({});
    setIsEditingAirline(false);
    setEditingAxisId(null);
    
    if (onAirlineSelect) {
      onAirlineSelect(airline);
    }
    
    await fetchFiltersForAirline(airline);
  };

  const fetchFiltersForAirline = async (airline) => {
    if (!isHomePage) return;
    
    try {
      const allowancesRes = await fetch(
        `${SUPABASE_URL}/rest/v1/allowances?airline_id=eq.${airline.id}&select=*`,
        { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } }
      );
      const allowancesData = await allowancesRes.json();
      const includedAllowances = Array.isArray(allowancesData) 
        ? allowancesData.filter(a => String(a.purchase_status).toLowerCase() === 'included')
        : [];
      
      setAllowances(includedAllowances);

      if (includedAllowances.length === 0) {
        if (onFiltersComplete) {
          onFiltersComplete({});
        }
        return;
      }

      const allowanceIds = includedAllowances.map(a => a.id).join(',');
      const conditionsRes = await fetch(
        `${SUPABASE_URL}/rest/v1/allowance_conditions?allowance_id=in.(${allowanceIds})&select=*`,
        { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } }
      );
      const conditionsData = await conditionsRes.json();
      const junctionData = Array.isArray(conditionsData) ? conditionsData : [];
      setAllowanceConditions(junctionData);

      const usedAxisIds = [...new Set(junctionData.map(j => j.axis_id))];
      const usedLabelIds = [...new Set(junctionData.map(j => j.label_id))];

      if (usedAxisIds.length === 0) {
        if (onFiltersComplete) {
          onFiltersComplete({});
        }
        return;
      }

      const [axesRes, labelsRes] = await Promise.all([
        fetch(
          `${SUPABASE_URL}/rest/v1/condition_axes?id=in.(${usedAxisIds.join(',')})&select=*`,
          { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } }
        ),
        fetch(
          `${SUPABASE_URL}/rest/v1/condition_labels?id=in.(${usedLabelIds.join(',')})&select=*`,
          { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } }
        )
      ]);

      const axesData = await axesRes.json();
      const labelsData = await labelsRes.json();

      const allAxesList = Array.isArray(axesData) ? axesData : [];
      const allLabels = Array.isArray(labelsData) ? labelsData : [];

      const axesWithMultipleLabels = allAxesList.filter(axis => {
        const axisLabels = allLabels.filter(l => l.axis_id === axis.id);
        return axisLabels.length > 1;
      });

      const meaningfulAxisIds = new Set(axesWithMultipleLabels.map(a => a.id));
      const filteredLabels = allLabels.filter(label => meaningfulAxisIds.has(label.axis_id));

      const sortedAxes = axesWithMultipleLabels.sort((a, b) => {
        const aLabelCount = filteredLabels.filter(l => l.axis_id === a.id).length;
        const bLabelCount = filteredLabels.filter(l => l.axis_id === b.id).length;
        return aLabelCount - bLabelCount;
      });

      setConditionAxes(sortedAxes);
      setConditionLabels(filteredLabels);

    } catch (error) {
      console.error("Error fetching filters:", error);
    }
  };

  const handleReset = () => {
    setIsEditingAirline(true);
    setSearchQuery("");
    setSelectedAirline(null);
    setConditionAxes([]);
    setConditionLabels([]);
    setSelectedLabelIds({});
    setShowDropdown(false);
    setEditingAxisId(null);
    
    if (onReset) {
      onReset();
    }
  };

  const handleEditAirline = () => {
    setIsEditingAirline(true);
    setSearchQuery("");
    setEditingAxisId(null);
    scrollToTop();
  };

  const handleEditFilter = (axisId) => {
    setEditingAxisId(axisId);
    scrollToTop();
  };

  const getSelectedLabelsWithAxis = () => {
    return conditionAxes
      .filter(axis => selectedLabelIds[axis.id] !== undefined)
      .map(axis => ({
        axis,
        label: conditionLabels.find(l => l.id === selectedLabelIds[axis.id])
      }))
      .filter(item => item.label);
  };

  const handleAddAnotherFlight = () => {
    if (onAddLeg) {
      const newLegId = `leg-${Date.now()}`;
      onAddLeg(newLegId);
    }
  };

  if (!isHomePage) {
    return null;
  }

  const hasSelectedFilters = getSelectedLabelsWithAxis().length > 0;
  const shouldShowFilters = editingAxisId !== null;
  const isInEditMode = isEditingAirline || shouldShowFilters;
  const canAddAnotherFlight = allFiltersComplete && !isInEditMode && onAddLeg;

  // Force compact mode when forceCompact is true (in sticky header)
  const showCompactMode = forceCompact || (allFiltersComplete && !isInEditMode);

  return (
    <div className="w-full relative" style={{ maxWidth: showResults ? '100%' : '42rem', margin: '0 auto' }}>
      <div 
        className="frosted-glass rounded-xl sm:rounded-2xl overflow-hidden search-box-container"
        style={{ 
          position: 'relative',
          boxShadow: '0 8px 32px var(--glass-shadow)',
          backgroundColor: 'var(--glass-bg)'
        }}
      >
        {!selectedAirline || isEditingAirline ? (
          <div className="flex items-center gap-2 sm:gap-3 p-3 sm:p-4 md:p-5">
            {showResults && (
              <button
                onClick={handleReset}
                style={{
                  flexShrink: 0,
                  padding: '0.5rem',
                  borderRadius: '0.5rem',
                  transition: 'background 0.2s, opacity 0.2s',
                  backgroundColor: 'transparent',
                  opacity: showSubtleRemove ? 0.4 : 1
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = showSubtleRemove ? 'rgba(239, 68, 68, 0.1)' : 'var(--hover-bg)';
                  e.currentTarget.style.opacity = 1;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                  e.currentTarget.style.opacity = showSubtleRemove ? 0.4 : 1;
                }}
                aria-label={showSubtleRemove ? "Remove this flight" : "Go back"}
              >
                <X className="w-5 h-5" style={{ color: showSubtleRemove ? '#EF4444' : 'var(--text-primary)' }} />
              </button>
            )}
            {isLoading ? (
              <Loader2 className="w-5 h-5 sm:w-6 sm:h-6 text-[#6B36FF] animate-spin flex-shrink-0" />
            ) : (
              <Search className="w-5 h-5 sm:w-6 sm:h-6 text-[#6B36FF] flex-shrink-0" />
            )}
            <Input
              type="text"
              placeholder={isLoading ? "Loading..." : "Find your airline"}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              disabled={isLoading || forceCompact}
              style={{
                flex: 1,
                background: 'transparent',
                border: 'none',
                color: 'var(--text-primary)',
                fontSize: 'clamp(0.9rem, 4vw, 1.125rem)',
                boxShadow: 'none'
              }}
              className="focus-visible:ring-0 focus-visible:ring-offset-0 disabled:opacity-50 placeholder:text-[var(--text-tertiary)]"
              autoFocus={!forceCompact}
            />
          </div>
        ) : showCompactMode ? (
          <div className="p-3 sm:p-4 md:p-5">
            <div className="flex items-center gap-2 sm:gap-3">
              <button
                onClick={handleReset}
                style={{
                  padding: '0.5rem',
                  borderRadius: '0.5rem',
                  transition: 'background 0.2s, opacity 0.2s',
                  flexShrink: 0,
                  backgroundColor: 'transparent',
                  opacity: showSubtleRemove ? 0.4 : 1
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = showSubtleRemove ? 'rgba(239, 68, 68, 0.1)' : 'var(--hover-bg)';
                  e.currentTarget.style.opacity = 1;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                  e.currentTarget.style.opacity = showSubtleRemove ? 0.4 : 1;
                }}
                aria-label={showSubtleRemove ? "Remove this flight" : "Go back"}
              >
                <X className="w-5 h-5" style={{ color: showSubtleRemove ? '#EF4444' : 'var(--text-primary)' }} />
              </button>

              <div className="flex items-center gap-1.5 sm:gap-2 flex-1 min-w-0 overflow-x-auto scrollbar-hide">
                <button
                  onClick={forceCompact ? undefined : handleEditAirline}
                  onMouseEnter={() => setIsHoveringAirline(true)}
                  onMouseLeave={() => setIsHoveringAirline(false)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.375rem',
                    padding: '0.25rem 0.5rem',
                    borderRadius: '0.5rem',
                    transition: 'background 0.2s',
                    flexShrink: 0,
                    backgroundColor: 'transparent',
                    cursor: forceCompact ? 'default' : 'pointer'
                  }}
                  onMouseOver={(e) => !forceCompact && (e.currentTarget.style.backgroundColor = 'var(--hover-bg)')}
                  onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                >
                  <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-md bg-white flex items-center justify-center overflow-hidden p-1 sm:p-1.5 flex-shrink-0">
                    {selectedAirline.logo_url ? (
                      <img 
                        src={selectedAirline.logo_url} 
                        alt={selectedAirline.airline_name}
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <Plane className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#6B36FF]" />
                    )}
                  </div>
                  <span className="text-xs sm:text-sm font-semibold whitespace-nowrap" style={{ color: 'var(--text-primary)' }}>
                    {selectedAirline.airline_name}
                  </span>
                  {!forceCompact && (
                    <Edit2 
                      className="w-2.5 h-2.5 sm:w-3 sm:h-3 flex-shrink-0" 
                      style={{ 
                        color: 'var(--text-tertiary)',
                        opacity: isHoveringAirline ? 1 : 0.3,
                        transition: 'opacity 0.2s'
                      }} 
                    />
                  )}
                </button>

                {hasSelectedFilters && <div style={{ height: '1.25rem', width: '1px', backgroundColor: 'var(--border-color)', flexShrink: 0 }} />}

                {hasSelectedFilters && getSelectedLabelsWithAxis().map((item, idx) => (
                  <button
                    key={idx}
                    onClick={forceCompact ? undefined : () => handleEditFilter(item.axis.id)}
                    style={{
                      padding: '0.25rem 0.5rem',
                      borderRadius: '0.375rem',
                      fontSize: '0.7rem',
                      fontWeight: 500,
                      color: 'var(--badge-text)',
                      backgroundColor: 'var(--badge-bg)',
                      border: '1px solid var(--card-border)',
                      transition: 'background 0.2s',
                      flexShrink: 0,
                      whiteSpace: 'nowrap',
                      cursor: forceCompact ? 'default' : 'pointer'
                    }}
                    onMouseEnter={(e) => !forceCompact && (e.currentTarget.style.backgroundColor = 'var(--hover-bg)')}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'var(--badge-bg)'}
                  >
                    {formatLabel(item.label.label)}
                  </button>
                ))}
              </div>

              {!forceCompact && (
                <>
                  <button
                    onClick={() => handleEditFilter(conditionAxes[0]?.id)}
                    style={{
                      padding: '0.5rem',
                      borderRadius: '0.5rem',
                      transition: 'background 0.2s',
                      flexShrink: 0,
                      backgroundColor: 'transparent'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'var(--hover-bg)'}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                    aria-label="Edit filters"
                  >
                    <Edit2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" style={{ color: 'var(--text-tertiary)' }} />
                  </button>

                  {canAddAnotherFlight && (
                    <button
                      onClick={handleAddAnotherFlight}
                      style={{
                        padding: '0.5rem',
                        borderRadius: '0.5rem',
                        transition: 'all 0.2s',
                        flexShrink: 0,
                        backgroundColor: '#6B36FF',
                        border: 'none'
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#5A2BE0'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#6B36FF'}
                      aria-label="Add another flight"
                    >
                      <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        ) : ( // This is the expanded filter view, when selectedAirline is true, but not compact and not initial/edit
          <div className="p-3 sm:p-4 md:p-5">
            <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
              <button
                onClick={handleReset}
                style={{
                  padding: '0.5rem',
                  borderRadius: '0.5rem',
                  transition: 'background 0.2s, opacity 0.2s',
                  flexShrink: 0,
                  backgroundColor: 'transparent',
                  opacity: showSubtleRemove ? 0.4 : 1
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = showSubtleRemove ? 'rgba(239, 68, 68, 0.1)' : 'var(--hover-bg)';
                  e.currentTarget.style.opacity = 1;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                  e.currentTarget.style.opacity = showSubtleRemove ? 0.4 : 1;
                }}
                aria-label={showSubtleRemove ? "Remove this flight" : "Go back"}
              >
                <X className="w-5 h-5" style={{ color: showSubtleRemove ? '#EF4444' : 'var(--text-primary)' }} />
              </button>

              <div className="flex-1 min-w-0">
                <button
                  onClick={handleEditAirline}
                  onMouseEnter={() => setIsHoveringAirline(true)}
                  onMouseLeave={() => setIsHoveringAirline(false)}
                  className="flex items-center gap-2 mb-2 hover:opacity-80 transition-opacity group w-full"
                >
                  <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-white flex items-center justify-center overflow-hidden p-1.5 sm:p-2 flex-shrink-0">
                    {selectedAirline.logo_url ? (
                      <img 
                        src={selectedAirline.logo_url} 
                        alt={selectedAirline.airline_name}
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <Plane className="w-4 h-4 sm:w-5 sm:h-5 text-[#6B36FF]" />
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
                    <h2 className="text-sm sm:text-base md:text-lg font-bold group-hover:text-[#6B36FF] transition-colors truncate" style={{ color: 'var(--text-primary)' }}>
                      {selectedAirline.airline_name}
                    </h2>
                    <Edit2 
                      className="w-3 h-3 sm:w-3.5 sm:h-3.5 transition-opacity flex-shrink-0" 
                      style={{ 
                        color: 'var(--text-tertiary)',
                        opacity: isHoveringAirline ? 1 : 0.3
                      }} 
                    />
                  </div>
                </button>

                {hasSelectedFilters && (
                  <div className="flex flex-wrap gap-1.5">
                    {getSelectedLabelsWithAxis().map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleEditFilter(item.axis.id)}
                        className="group relative px-2 sm:px-2.5 py-1 rounded-full transition-all duration-200 cursor-pointer"
                        style={{
                          background: editingAxisId === item.axis.id 
                            ? 'linear-gradient(135deg, rgba(107, 54, 255, 0.3), rgba(217, 76, 255, 0.3))'
                            : 'linear-gradient(135deg, rgba(107, 54, 255, 0.15), rgba(217, 76, 255, 0.15))',
                          border: editingAxisId === item.axis.id
                            ? '1.5px solid rgba(107, 54, 255, 0.7)'
                            : '1.5px solid rgba(107, 54, 255, 0.3)',
                        }}
                      >
                        <span className="text-xs font-semibold" style={{ color: 'var(--filter-text-selected)' }}>
                          {formatLabel(item.label.label)}
                        </span>
                      </button>
                    ))}
                  </div>
                )}

                {selectedAirline.last_refreshed_at && (
                  <div className="mt-2">
                    <LiveDataBadge lastRefreshedAt={selectedAirline.last_refreshed_at} />
                  </div>
                )}
              </div>
            </div>

            {conditionAxes.length > 0 && (
              <div className="pt-3 sm:pt-4" style={{ borderTop: '1px solid var(--border-color)' }}>
                <ConditionFilters
                  conditionAxes={conditionAxes}
                  conditionLabels={conditionLabels}
                  selectedLabelIds={selectedLabelIds}
                  setSelectedLabelIds={setSelectedLabelIds}
                  allowances={allowances}
                  allowanceConditions={allowanceConditions}
                  editingAxisId={editingAxisId}
                  onEditComplete={() => setEditingAxisId(null)}
                />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Dropdown - only show if not forced compact */}
      <AnimatePresence>
        {!forceCompact && showDropdown && (filteredAirlines.length > 0 || noResultsFound) && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            style={{
              position: 'absolute',
              top: '100%',
              left: 0,
              right: 0,
              marginTop: '0.5rem',
              zIndex: 200
            }}
          >
            <div 
              className="dropdown-solid rounded-xl sm:rounded-2xl overflow-hidden"
              style={{
                maxHeight: '20rem',
                overflowY: 'auto',
                backgroundColor: 'var(--bg-primary)',
                border: '1px solid var(--border-color-strong)',
                boxShadow: '0 20px 60px var(--shadow-color)',
              }}
            >
              {noResultsFound ? (
                <div
                  style={{
                    padding: '1.5rem 1rem',
                    textAlign: 'center',
                  }}
                >
                  <Plane className="w-10 h-10 mx-auto mb-3 opacity-30" style={{ color: 'var(--text-tertiary)' }} />
                  <p className="text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                    This airline hasn't landed yet in our list.
                  </p>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                    <Link 
                      to={createPageUrl('Contact')}
                      className="text-[#6B36FF] hover:text-[#D94CFF] underline font-medium"
                    >
                      Contact us
                    </Link>
                    {' '}with your request and we'll add it soon!
                  </p>
                </div>
              ) : (
                filteredAirlines.map((airline) => (
                  <button
                    key={airline.id}
                    onClick={() => handleAirlineSelect(airline)}
                    className="dropdown-item"
                    style={{
                      width: '100%',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.75rem',
                      padding: '0.75rem 1rem',
                      transition: 'all 0.2s ease',
                      textAlign: 'left',
                      backgroundColor: 'transparent'
                    }}
                  >
                    <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-white flex items-center justify-center flex-shrink-0 overflow-hidden p-1.5">
                      {airline.logo_url ? (
                        <img 
                          src={airline.logo_url} 
                          alt={airline.airline_name}
                          className="w-full h-full object-contain"
                        />
                      ) : (
                        <Plane className="w-5 h-5 text-[#6B36FF]" />
                      )}
                    </div>
                    <span className="text-sm sm:text-base font-medium" style={{ color: 'var(--text-primary)' }}>
                      {airline.airline_name}
                    </span>
                  </button>
                ))
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {error && (
        <div className="mt-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
          <p className="text-red-400 text-xs sm:text-sm">Unable to load airlines. Please refresh.</p>
        </div>
      )}

      <style>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        
        .dropdown-item:hover {
          background-color: var(--hover-bg);
        }
        
        .dropdown-solid::-webkit-scrollbar {
          width: 6px;
        }
        
        .dropdown-solid::-webkit-scrollbar-track {
          background: transparent;
        }
        
        .dropdown-solid::-webkit-scrollbar-thumb {
          background: var(--border-color-strong);
          border-radius: 10px;
        }
      `}</style>
    </div>
  );
}
