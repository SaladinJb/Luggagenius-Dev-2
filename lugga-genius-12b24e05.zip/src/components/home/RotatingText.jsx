import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const phrases = [
  "Compare airline allowances.",
  "Find allowance for multi-airline flights.",
  "Check your airline allowance."
];

export default function RotatingText() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % phrases.length);
    }, 3000); // Change every 3 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-16 sm:h-20 flex items-center justify-center">
      <style>{`
        .gradient-glow-text {
          background: linear-gradient(135deg, #6B36FF 0%, #D94CFF 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          filter: drop-shadow(0 0 20px rgba(107, 54, 255, 0.5));
        }
      `}</style>
      
      <AnimatePresence mode="wait">
        <motion.p
          key={currentIndex}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
          className="gradient-glow-text text-xl sm:text-2xl md:text-3xl font-medium px-4 text-center"
        >
          {phrases[currentIndex]}
        </motion.p>
      </AnimatePresence>
    </div>
  );
}