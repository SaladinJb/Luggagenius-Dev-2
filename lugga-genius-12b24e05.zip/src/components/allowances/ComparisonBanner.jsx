import React, { useState } from "react";
import { motion } from "framer-motion";
import { TrendingUp, Check, AlertCircle, Zap, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";

const ExpandableText = ({ text, label }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const maxLength = 100;

  if (!text || text.length <= maxLength) {
    return (
      <p className="text-xs sm:text-sm break-words whitespace-pre-wrap" style={{ color: 'var(--text-primary)' }}>
        {text}
      </p>);

  }

  return (
    <div>
      <p className="text-xs sm:text-sm break-words whitespace-pre-wrap" style={{ color: 'var(--text-primary)' }}>
        {isExpanded ? text : `${text.substring(0, maxLength)}...`}
      </p>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="mt-1 text-xs font-medium text-[#6B36FF] hover:text-[#D94CFF] transition-colors flex items-center gap-1">

        {isExpanded ?
        <>
            <ChevronUp className="w-3 h-3" />
            Less
          </> :

        <>
            <ChevronDown className="w-3 h-3" />
            More
          </>
        }
      </button>
    </div>);

};

export default function ComparisonBanner({ allowances, airline, purchaseUrl }) {
  if (!airline || !allowances || allowances.length === 0) {
    return null;
  }

  const upgradeCostText = airline.upgrade_cost || 'Contact airline for pricing';
  const upgradeBenefits = airline.upgrade_notes;
  const excessFeesText = airline.excess_fees || 'Pay at the gate if you exceed limits';

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="frosted-glass rounded-2xl sm:rounded-3xl overflow-hidden my-8 sm:my-12"
      id="comparison-banner">

      <div className="p-4 sm:p-6 md:p-8" style={{ background: 'linear-gradient(135deg, rgba(107, 54, 255, 0.1), rgba(217, 76, 255, 0.1))' }}>
        <div className="text-center mb-6 sm:mb-8">
          <div className="inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full mb-3 sm:mb-4" style={{ backgroundColor: 'var(--warning-yellow-bg)', border: '1px solid var(--warning-yellow-border)' }}>
            <Zap className="w-3 h-3 sm:w-4 sm:h-4" style={{ color: 'var(--warning-yellow)' }} />
            <span className="text-xs sm:text-sm font-bold" style={{ color: 'var(--warning-yellow)' }}>SMART TRAVELER RECOMMENDATION</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold mb-2 px-4" style={{ color: 'var(--text-primary)' }}>
            Upgrade Your Baggage Allowance
          </h2>
          <p className="text-base sm:text-lg px-4" style={{ color: 'var(--text-secondary)' }}>
            Get more flexibility and avoid surprises at the airport
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 max-w-4xl mx-auto">
          <div className="rounded-xl sm:rounded-2xl p-4 sm:p-6 border-2" style={{ backgroundColor: 'rgba(255, 107, 107, 0.05)', borderColor: 'rgba(255, 107, 107, 0.3)' }}>
            <div className="flex items-center gap-2 mb-4">
              <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 text-[#FF6B6B]" />
              <h3 className="text-base sm:text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Current Allowances</h3>
            </div>
            
            <div className="space-y-2 sm:space-y-3 mb-4 sm:mb-6">
              <div className="flex items-start gap-2">
                <span className="text-[#FF6B6B] flex-shrink-0">✗</span>
                <p className="text-xs sm:text-sm" style={{ color: 'var(--text-secondary)' }}>Limited baggage allowance</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-[#FF6B6B] flex-shrink-0">✗</span>
                <p className="text-xs sm:text-sm" style={{ color: 'var(--text-secondary)' }}>Risk of excess baggage fees</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-[#FF6B6B] flex-shrink-0">✗</span>
                <p className="text-xs sm:text-sm" style={{ color: 'var(--text-secondary)' }}>Stress at check-in counter</p>
              </div>
            </div>

            <div className="p-3 rounded-lg" style={{ backgroundColor: 'rgba(255, 107, 107, 0.1)', border: '1px solid rgba(255, 107, 107, 0.3)' }}>
              <p className="text-xs sm:text-sm font-semibold text-[#FF6B6B] mb-1">Potential Excess Fees:</p>
              <ExpandableText text={excessFeesText} label="excess fees" />
            </div>
          </div>

          <div className="rounded-xl sm:rounded-2xl p-4 sm:p-6 border-2 relative" style={{ background: 'linear-gradient(135deg, rgba(107, 54, 255, 0.1), rgba(217, 76, 255, 0.1))', borderColor: 'rgba(107, 54, 255, 0.5)' }}>
            <div className="absolute -top-2 sm:-top-3 -right-2 sm:-right-3">
              <span className="text-violet-700 px-2 py-0.5 text-xs font-bold rounded-full sm:px-3 sm:py-1 shadow-lg" style={{ backgroundColor: 'var(--warning-yellow)' }}>RECOMMENDED

              </span>
            </div>

            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-[#6B36FF]" />
              <h3 className="text-base sm:text-lg font-bold" style={{ color: 'var(--text-primary)' }}>With Upgrade</h3>
            </div>

            <div className="space-y-2 sm:space-y-3 mb-4 sm:mb-6">
              {upgradeBenefits ?
              <>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 sm:w-5 sm:h-5 text-[#6BCF7F] flex-shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <ExpandableText text={upgradeBenefits} label="upgrade benefits" />
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 sm:w-5 sm:h-5 text-[#6BCF7F] flex-shrink-0" />
                    <p className="text-xs sm:text-sm" style={{ color: 'var(--text-primary)' }}>No excess baggage fees</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 sm:w-5 sm:h-5 text-[#6BCF7F] flex-shrink-0" />
                    <p className="text-xs sm:text-sm" style={{ color: 'var(--text-primary)' }}>Travel stress-free</p>
                  </div>
                </> :

              <>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 sm:w-5 sm:h-5 text-[#6BCF7F] flex-shrink-0" />
                    <p className="text-xs sm:text-sm" style={{ color: 'var(--text-primary)' }}>Extra baggage allowance</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 sm:w-5 sm:h-5 text-[#6BCF7F] flex-shrink-0" />
                    <p className="text-xs sm:text-sm" style={{ color: 'var(--text-primary)' }}>No excess baggage fees</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="w-4 h-4 sm:w-5 sm:h-5 text-[#6BCF7F] flex-shrink-0" />
                    <p className="text-xs sm:text-sm" style={{ color: 'var(--text-primary)' }}>Travel stress-free</p>
                  </div>
                </>
              }
            </div>

            {airline.upgrade_cost &&
            <div className="p-3 rounded-lg mb-3 sm:mb-4" style={{ backgroundColor: 'rgba(107, 54, 255, 0.2)', border: '1px solid rgba(107, 54, 255, 0.4)' }}>
                <p className="text-xs sm:text-sm font-semibold text-[#6B36FF] mb-1">Upgrade Cost:</p>
                <ExpandableText text={upgradeCostText} label="upgrade cost" />
              </div>
            }

            <Button
              onClick={() => window.open(airline.baggage_policy_url || airline.official_website_url || purchaseUrl, '_blank')}
              className="w-full bg-gradient-to-r from-[#6B36FF] to-[#D94CFF] hover:opacity-90 text-white font-bold py-2.5 sm:py-3 text-sm sm:text-base">

              <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" />
              {airline.upgrade_cost ? 'Upgrade Now & Save' : 'View Options'}
            </Button>
          </div>
        </div>

        <div className="mt-6 sm:mt-8 text-center px-4">
          <p className="text-xs sm:text-sm font-medium" style={{ color: 'var(--warning-yellow)' }}>
            💡 Most travelers choose to upgrade to avoid airport surprises
          </p>
        </div>
      </div>
    </motion.div>);

}