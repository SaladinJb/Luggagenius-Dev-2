import React from "react";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function LiveDataBadge({ lastRefreshedAt }) {
  if (!lastRefreshedAt) return null;

  const formattedDate = format(new Date(lastRefreshedAt), 'MMM d, yyyy');

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10"
    >
      <style>{`
        @keyframes pulse-ring {
          0% {
            transform: scale(1);
            opacity: 1;
          }
          100% {
            transform: scale(1.5);
            opacity: 0;
          }
        }

        .live-dot {
          position: relative;
        }

        .live-dot::before,
        .live-dot::after {
          content: '';
          position: absolute;
          inset: 0;
          border-radius: 50%;
          background: #6BCF7F;
          animation: pulse-ring 2s ease-out infinite;
        }

        .live-dot::after {
          animation-delay: 1s;
        }
      `}</style>

      <div className="relative w-2 h-2">
        <div className="live-dot w-2 h-2 rounded-full bg-[#6BCF7F]" />
      </div>
      <span className="text-sm text-[#C8CDD3]">
        Live data • Updated {formattedDate}
      </span>
    </motion.div>
  );
}