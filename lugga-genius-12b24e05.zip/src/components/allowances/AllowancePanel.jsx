import React, { useState } from "react";
import { Package, Weight, Ruler, Briefcase, ExternalLink, ShoppingCart, Calculator, AlertTriangle, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { calculateAllowanceRisk, shouldShowUpsell, getRiskColor, getRiskIndicator } from "./AllowanceRiskAnalyzer";
import { useUnitSystem } from "../UnitSystemProvider";

const typeIcons = {
  "Personal Item": Briefcase,
  "Carry-on": Package,
  "Checked": Weight,
  "Special Items": Ruler,
};

const formatType = (type) => {
  if (!type) return '';
  return type
    .replace(/_/g, '-')
    .toLowerCase()
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join('-');
};

const ExpandableText = ({ text, label }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const maxLength = 150;
  
  if (!text || text.length <= maxLength) {
    return (
      <p className="text-xs sm:text-sm break-words whitespace-pre-wrap" style={{ color: 'var(--text-primary)' }}>
        {text}
      </p>
    );
  }

  return (
    <div>
      <p className="text-xs sm:text-sm break-words whitespace-pre-wrap" style={{ color: 'var(--text-primary)' }}>
        {isExpanded ? text : `${text.substring(0, maxLength)}...`}
      </p>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="mt-2 text-xs font-medium text-[#6B36FF] hover:text-[#D94CFF] transition-colors flex items-center gap-1"
      >
        {isExpanded ? (
          <>
            <ChevronUp className="w-3 h-3" />
            Show less
          </>
        ) : (
          <>
            <ChevronDown className="w-3 h-3" />
            Read more
          </>
        )}
      </button>
    </div>
  );
};

export default function AllowancePanel({ type, allowances, purchaseUrl, delay, airline, isMultiJourney }) {
  const Icon = typeIcons[type] || Package;
  const hasAllowances = allowances && allowances.length > 0;
  const { formatWeight, formatDimensions } = useUnitSystem();

  const getFirstSentence = (text) => {
    if (!text) return '';
    const match = text.match(/^[^.!?]+[.!?]/);
    return match ? match[0] : text;
  };

  return (
    <div className="frosted-glass rounded-2xl sm:rounded-3xl overflow-hidden">
      <div className="p-4 sm:p-6 md:p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center flex-shrink-0">
            <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>{type}</h2>
            {hasAllowances && (
              <p className="text-xs sm:text-sm" style={{ color: 'var(--text-tertiary)' }}>{allowances.length} allowance{allowances.length !== 1 ? 's' : ''}</p>
            )}
          </div>
        </div>

        {airline?.calculator && (
          <div 
            onClick={() => window.open(airline.baggage_policy_url || airline.official_website_url, '_blank')}
            className="mb-6 px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg sm:rounded-xl border cursor-pointer transition-all hover:opacity-80" 
            style={{ 
              backgroundColor: 'var(--note-bg)', 
              borderColor: 'var(--note-border)'
            }}
          >
            <div className="flex items-center gap-2 sm:gap-3">
              <Calculator className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" style={{ color: 'var(--note-text)' }} />
              <div className="flex-1 min-w-0">
                <p className="text-xs sm:text-sm font-medium" style={{ color: 'var(--note-text)' }}>
                  <span className="block sm:hidden">{getFirstSentence(`${airline?.airline_name || 'This airline'} uses a calculator.`)}</span>
                  <span className="hidden sm:block">{airline?.airline_name || 'This airline'} uses a calculator. Check their tool.</span>
                </p>
              </div>
              <ExternalLink className="w-4 h-4 flex-shrink-0 hidden sm:block" style={{ color: 'var(--note-text)' }} />
            </div>
          </div>
        )}

        {hasAllowances ? (
          <div className="space-y-6">
            {allowances.map((allowance, index) => {
              const riskAnalysis = calculateAllowanceRisk(allowance);
              const showUpsell = shouldShowUpsell(allowance, airline);

              return (
                <div
                  key={index}
                  className="space-y-4"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <p className="text-xs uppercase tracking-wider" style={{ color: 'var(--text-tertiary)' }}>Pieces Allowed</p>
                      <p className="font-medium text-base sm:text-lg" style={{ color: 'var(--text-primary)' }}>
                        {allowance.pieces_allowed || 'Not specified'}
                      </p>
                    </div>

                    <div className="space-y-1">
                      <p className="text-xs uppercase tracking-wider" style={{ color: 'var(--text-tertiary)' }}>Weight Limit</p>
                      <p className="font-medium text-base sm:text-lg" style={{ color: 'var(--text-primary)' }}>
                        {formatWeight(allowance.weight_limit_kg)}
                      </p>
                    </div>

                    <div className="space-y-1">
                      <p className="text-xs uppercase tracking-wider" style={{ color: 'var(--text-tertiary)' }}>Dimensions</p>
                      <p className="font-medium text-sm sm:text-base" style={{ color: 'var(--text-primary)' }}>
                        {formatDimensions(
                          allowance.dim_length_cm,
                          allowance.dim_width_cm,
                          allowance.dim_height_cm,
                          allowance.dimension_type
                        )}
                      </p>
                    </div>
                  </div>

                  {allowance.notes && (
                    <div className="p-3 rounded-xl border" style={{ backgroundColor: 'var(--note-bg)', borderColor: 'var(--note-border)' }}>
                      <ExpandableText text={allowance.notes} label="notes" />
                    </div>
                  )}

                  {riskAnalysis.level !== 'low' && (
                    <div className="flex items-center gap-2">
                      <Badge 
                        className="border px-3 py-1.5 text-xs font-semibold"
                        style={{ 
                          backgroundColor: 'var(--warning-yellow-badge)', 
                          color: 'var(--warning-yellow)',
                          borderColor: 'var(--warning-yellow-border)'
                        }}
                      >
                        ⚠️ {riskAnalysis.level === 'high' ? 'Tight Limits' : 'Consider Upgrade'}
                      </Badge>
                    </div>
                  )}

                  {riskAnalysis.warnings.length > 0 && (
                    <div className="p-3 rounded-lg" style={{ 
                      backgroundColor: 'var(--warning-yellow-bg)', 
                      borderLeft: '3px solid var(--warning-yellow)' 
                    }}>
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: 'var(--warning-yellow)' }} />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold mb-1" style={{ color: 'var(--warning-yellow)' }}>
                            Restrictive Allowance
                          </p>
                          {riskAnalysis.warnings.map((warning, idx) => (
                            <p key={idx} className="text-xs break-words" style={{ color: 'var(--text-secondary)' }}>• {warning}</p>
                          ))}
                          {showUpsell && airline.upgrade_cost && (
                            <p className="text-xs font-medium text-[#6B36FF] mt-2">
                              💡 Consider upgrading to avoid fees
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {allowance.source_url && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => window.open(allowance.source_url, '_blank')}
                      className="text-[#6B36FF] hover:text-[#D94CFF] text-xs sm:text-sm"
                      style={{ backgroundColor: 'transparent' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'var(--hover-bg)'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                    >
                      <ExternalLink className="w-3 h-3 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" />
                      Check for yourself
                    </Button>
                  )}

                  {index < allowances.length - 1 && (
                    <div className="pt-6" style={{ borderTop: '1px solid var(--border-color)' }} />
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-6 sm:py-8">
            <ShoppingCart className="w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-3 sm:mb-4 opacity-50" style={{ color: 'var(--text-tertiary)' }} />
            <p className="text-base sm:text-lg mb-3 sm:mb-4 px-4" style={{ color: 'var(--text-secondary)' }}>
              Not available under selected conditions
            </p>
            <Button
              onClick={() => window.open(purchaseUrl, '_blank')}
              className="bg-gradient-to-r from-[#6B36FF] to-[#D94CFF] hover:opacity-90 text-white text-sm sm:text-base"
            >
              View Purchase Options
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}