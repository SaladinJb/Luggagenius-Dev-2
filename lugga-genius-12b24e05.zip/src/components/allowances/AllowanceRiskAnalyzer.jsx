/**
 * Baggage Allowance Risk Analyzer
 * 
 * Analyzes allowance restrictions and provides risk assessment for users.
 * Used to determine when to show upsell content and calculate potential savings.
 */

// Benchmark values for "typical" allowances - ONLY FOR WEIGHT
const WEIGHT_BENCHMARKS = {
  personal_item: 10,
  carry_on: 15,
  checked: 23,
  special_items: 23
};

const BENCHMARKS = {
  PIECES: 1,
  EXCESS_FEE_PER_KG: 15,
  EXCESS_FEE_FLAT: 100
};

/**
 * Format raw database labels to human-readable text
 */
const formatLabel = (text) => {
  if (!text) return '';
  return text
    .replace(/_/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

/**
 * Clean allowance type for better readability
 */
const formatAllowanceType = (type) => {
  if (!type) return '';
  const cleanType = String(type)
    .replace(/_/g, ' ')
    .replace(/carr on/gi, 'carry-on')
    .replace(/carry on/gi, 'carry-on')
    .trim();
  return formatLabel(cleanType);
};

/**
 * Get the appropriate weight benchmark for an allowance type
 */
const getWeightBenchmark = (allowanceType) => {
  const type = String(allowanceType || '').toLowerCase().replace(/[_\s-]/g, '');
  if (type.includes('personalitem')) return WEIGHT_BENCHMARKS.personal_item;
  if (type.includes('carryon') || type.includes('carron')) return WEIGHT_BENCHMARKS.carry_on;
  if (type.includes('checked')) return WEIGHT_BENCHMARKS.checked;
  if (type.includes('special')) return WEIGHT_BENCHMARKS.special_items;
  return WEIGHT_BENCHMARKS.checked;
};

/**
 * Calculate risk score and provide analysis for an allowance
 */
export const calculateAllowanceRisk = (allowance) => {
  let riskScore = 0;
  const reasons = [];
  const warnings = [];

  if (allowance.weight_limit_kg) {
    const weight = parseFloat(allowance.weight_limit_kg);
    const benchmark = getWeightBenchmark(allowance.type);
    
    if (weight < benchmark) {
      const difference = benchmark - weight;
      riskScore += (difference / benchmark) * 40;
      reasons.push('low_weight');
      const formattedType = formatAllowanceType(allowance.type);
      warnings.push(`Weight limit is ${difference}kg below typical for ${formattedType} (${weight}kg vs ${benchmark}kg)`);
    }
  }

  if (allowance.pieces_allowed) {
    const pieces = parseInt(allowance.pieces_allowed);
    if (pieces < BENCHMARKS.PIECES) {
      riskScore += 25;
      reasons.push('limited_pieces');
      warnings.push(`Only ${pieces} piece(s) allowed`);
    }
  }

  let level = 'low';
  if (riskScore >= 60) {
    level = 'high';
  } else if (riskScore >= 30) {
    level = 'medium';
  }

  return {
    score: riskScore,
    level,
    reasons,
    warnings
  };
};

/**
 * Determine if we should show upsell content to user
 */
export const shouldShowUpsell = (allowance, airline) => {
  const risk = calculateAllowanceRisk(allowance);
  return risk.level !== 'low' && airline?.upgrade_cost;
};

/**
 * Calculate potential savings from upgrade
 */
export const calculateUpgradeSavings = (allowance, airline) => {
  if (!airline?.upgrade_cost) return null;

  const risk = calculateAllowanceRisk(allowance);
  if (risk.level === 'low') return null;

  let estimatedExcessFees = 0;

  if (allowance.weight_limit_kg) {
    const weight = parseFloat(allowance.weight_limit_kg);
    const benchmark = getWeightBenchmark(allowance.type);
    
    if (weight < benchmark) {
      const excessKg = benchmark - weight;
      estimatedExcessFees += excessKg * BENCHMARKS.EXCESS_FEE_PER_KG;
    }
  }

  if (allowance.pieces_allowed) {
    const pieces = parseInt(allowance.pieces_allowed);
    if (pieces < BENCHMARKS.PIECES) {
      estimatedExcessFees += BENCHMARKS.EXCESS_FEE_FLAT;
    }
  }

  const upgradeCost = parseFloat(airline.upgrade_cost);
  const potentialSavings = estimatedExcessFees - upgradeCost;

  return {
    estimatedExcessFees,
    upgradeCost,
    potentialSavings,
    worthUpgrading: potentialSavings > 0
  };
};

/**
 * Build comparison data for upgrade messaging
 */
export const buildComparisonData = (allowances, airline) => {
  if (!airline) return null;

  const restrictiveAllowances = allowances
    .map(a => ({
      allowance: a,
      risk: calculateAllowanceRisk(a)
    }))
    .filter(item => item.risk.level !== 'low')
    .sort((a, b) => b.risk.score - a.risk.score);

  if (restrictiveAllowances.length === 0) return null;

  const topRestriction = restrictiveAllowances[0];
  const savings = calculateUpgradeSavings(topRestriction.allowance, airline);

  return {
    currentAllowance: topRestriction.allowance,
    riskAnalysis: topRestriction.risk,
    savings,
    upgradeInfo: airline.upgrade_notes || 'Upgrade to enjoy more generous baggage allowances'
  };
};

/**
 * UI Helper: Get color for risk level
 */
export const getRiskColor = (level) => {
  switch (level) {
    case 'high': return '#FF6B6B';
    case 'medium': return 'var(--warning-yellow)';
    default: return '#6BCF7F';
  }
};

/**
 * UI Helper: Get indicator icon for risk level
 */
export const getRiskIndicator = (level) => {
  switch (level) {
    case 'high': return '🚨';
    case 'medium': return '⚠️';
    default: return '✅';
  }
};