
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, AlertTriangle, Info, CheckCircle } from "lucide-react";

const formatLabel = (text) => {
  if (!text) return '';
  return text
    .replace(/_/g, ' ')
    .toLowerCase()
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

const getEnforcementIcon = (level) => {
  const levelLower = String(level).toLowerCase();
  if (levelLower.includes('strict')) return AlertTriangle;
  if (levelLower.includes('moderate')) return Shield;
  return CheckCircle;
};

const getEnforcementColor = (level) => {
  const levelLower = String(level).toLowerCase();
  if (levelLower.includes('strict')) return '#FF6B6B';
  if (levelLower.includes('moderate')) return 'var(--warning-yellow)';
  return '#6BCF7F';
};

const getBadgeIcon = (level) => {
  const levelLower = String(level).toLowerCase();
  if (levelLower.includes('strict')) return '🚨';
  return '⚠️';
};

export default function EnforcementWidget({ enforcementLevel, enforcementNotes, isCompact = false, hideBadge = false }) {
  const [showTooltip, setShowTooltip] = useState(false);
  
  if (!enforcementLevel) return null;

  const Icon = getEnforcementIcon(enforcementLevel);
  const color = getEnforcementColor(enforcementLevel);
  const badgeColor = getEnforcementColor(enforcementLevel);
  const badgeIcon = getBadgeIcon(enforcementLevel);
  
  const hasValidNotes = enforcementNotes && 
    enforcementNotes.trim() !== '' && 
    !enforcementNotes.toLowerCase().includes('no enforcement data') &&
    !enforcementNotes.toLowerCase().includes('not found') &&
    !enforcementNotes.toLowerCase().includes('n/a');
  
  const getGenericMessage = (level) => {
    const levelLower = String(level).toLowerCase();
    
    if (levelLower.includes('strict')) {
      return "This airline strictly enforces baggage policies. Expect thorough checks at check-in and boarding. Make sure your luggage meets all requirements to avoid additional fees.";
    }
    
    if (levelLower.includes('moderate')) {
      return "This airline enforces baggage policies with reasonable consistency. While they do check baggage dimensions and weight, minor deviations may be overlooked. Still, it's best to stay within limits.";
    }
    
    return "This airline has lenient baggage enforcement. While policies exist, they're typically flexible with minor variations. However, significantly oversized or overweight bags may still incur fees.";
  };
  
  const displayNotes = hasValidNotes ? enforcementNotes : getGenericMessage(enforcementLevel);

  const isModerate = String(enforcementLevel).toLowerCase().includes('moderate');

  // Compact layout (multi-journey or mobile)
  if (isCompact) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="frosted-glass rounded-xl p-4 border-l-4"
        style={{ borderLeftColor: color }}
      >
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div 
              className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: isModerate ? 'var(--warning-yellow-badge)' : `${color}20` }}
            >
              <Icon className="w-4 h-4" style={{ color }} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="text-xs font-semibold" style={{ color: 'var(--text-primary)' }}>Enforcement Level</h3>
                <div className="relative">
                  <button
                    onMouseEnter={() => setShowTooltip(true)}
                    onMouseLeave={() => setShowTooltip(false)}
                    className="w-4 h-4 rounded-full flex items-center justify-center transition-colors"
                    style={{ backgroundColor: 'var(--hover-bg)' }}
                    onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'var(--badge-bg)'}
                    onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'var(--hover-bg)'}
                  >
                    <Info className="w-2.5 h-2.5" style={{ color: 'var(--text-tertiary)' }} />
                  </button>
                  
                  <AnimatePresence>
                    {showTooltip && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute left-0 top-6 w-56 rounded-xl p-3 shadow-2xl z-50"
                        style={{ 
                          backgroundColor: 'var(--glass-bg-strong)', 
                          border: '1px solid var(--border-color)',
                          backdropFilter: 'blur(20px)'
                        }}
                      >
                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                          How strictly this airline enforces baggage policies. <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>Pay attention</span> to avoid fees!
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
              <p className="text-sm font-medium" style={{ color }}>{formatLabel(enforcementLevel)}</p>
            </div>
          </div>
          
          {!hideBadge && (
            <div 
              className="flex-shrink-0 px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap" 
              style={{ 
                backgroundColor: isModerate ? 'var(--warning-yellow-badge)' : `${badgeColor}15`, 
                color: badgeColor 
              }}
            >
              {badgeIcon} Know your limits
            </div>
          )}
        </div>
        
        <p className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
          {displayNotes}
        </p>
      </motion.div>
    );
  }

  // Standard layout for single journey
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="frosted-glass rounded-xl sm:rounded-2xl p-4 sm:p-5 border-l-4 relative"
      style={{ borderLeftColor: color, zIndex: 10 }}
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6">
        <div className="flex items-center gap-3 flex-shrink-0">
          <div 
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ backgroundColor: isModerate ? 'var(--warning-yellow-badge)' : `${color}20` }}
          >
            <Icon className="w-4 h-4 sm:w-5 sm:h-5" style={{ color }} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-xs sm:text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>Enforcement Level</h3>
              <div className="relative">
                <button
                  onMouseEnter={() => setShowTooltip(true)}
                  onMouseLeave={() => setShowTooltip(false)}
                  className="w-4 h-4 rounded-full flex items-center justify-center transition-colors"
                  style={{ backgroundColor: 'var(--hover-bg)' }}
                  onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'var(--badge-bg)'}
                  onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'var(--hover-bg)'}
                >
                  <Info className="w-2.5 h-2.5 sm:w-3 sm:h-3" style={{ color: 'var(--text-tertiary)' }} />
                </button>
                
                <AnimatePresence>
                  {showTooltip && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute left-0 top-6 w-56 sm:w-64 rounded-xl p-3 shadow-2xl z-50"
                      style={{ 
                        backgroundColor: 'var(--glass-bg-strong)', 
                        border: '1px solid var(--border-color)',
                        backdropFilter: 'blur(20px)'
                      }}
                    >
                      <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                        How strictly this airline enforces baggage policies. <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>Pay attention</span> to avoid fees!
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
            <p className="text-xs sm:text-sm font-medium" style={{ color }}>{formatLabel(enforcementLevel)}</p>
          </div>
        </div>

        <div className="flex-1 flex items-center justify-start sm:justify-center">
          <p className="text-xs leading-relaxed text-left sm:text-center break-words" style={{ color: 'var(--text-secondary)' }}>
            {displayNotes}
          </p>
        </div>

        {!hideBadge && (
          <div 
            className="flex-shrink-0 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-medium self-start sm:self-auto" 
            style={{ 
              backgroundColor: isModerate ? 'var(--warning-yellow-badge)' : `${badgeColor}15`, 
              color: badgeColor 
            }}
          >
            {badgeIcon} Know your limits
          </div>
        )}
      </div>
    </motion.div>
  );
}
