import React from "react";
import { Calculator, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CalculatorWidget({ policyUrl }) {
  if (!policyUrl) return null;

  return (
    <div className="mt-4 p-4 rounded-xl bg-[#FFD93D]/10 border border-[#FFD93D]/30 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#FFD93D]/30 to-[#FF6B6B]/30 flex items-center justify-center">
          <Calculator className="w-4 h-4 text-[#FFD93D]" />
        </div>
        <div>
          <p className="text-xs font-semibold text-[#F8F8F8]">Calculator Required</p>
          <p className="text-xs text-[#C8CDD3]">Allowances vary by route & fare</p>
        </div>
      </div>
      <Button
        onClick={() => window.open(policyUrl, '_blank')}
        size="sm"
        className="bg-gradient-to-r from-[#6B36FF] to-[#D94CFF] hover:opacity-90 text-white"
      >
        <ExternalLink className="w-3 h-3 mr-1.5" />
        Use Calculator
      </Button>
    </div>
  );
}