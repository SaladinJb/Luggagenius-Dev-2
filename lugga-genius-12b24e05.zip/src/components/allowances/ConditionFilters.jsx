import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check } from "lucide-react";

const formatLabel = (text) => {
  if (!text) return '';
  return text
    .replace(/_/g, '-')
    .toLowerCase()
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join('-');
};

const getHumanQuestion = (axisName) => {
  const lowerAxisName = axisName?.toLowerCase() || '';
  
  if (lowerAxisName.includes('class') || lowerAxisName.includes('cabin')) {
    return "What's your ticket class?";
  }
  if (lowerAxisName.includes('route')) {
    return "What's your route type?";
  }
  if (lowerAxisName.includes('membership') || lowerAxisName.includes('status') || lowerAxisName.includes('loyalty')) {
    return "Do you have a loyalty status?";
  }
  if (lowerAxisName.includes('region') || lowerAxisName.includes('zone')) {
    return "What's your travel region?";
  }
  if (lowerAxisName.includes('type')) {
    return "What type?";
  }
  
  return `Select your ${formatLabel(axisName || '')}`;
};

const StepIndicator = ({ currentStep, totalSteps }) => {
  return (
    <div className="flex justify-center items-center gap-1.5 sm:gap-2 mb-4 sm:mb-6">
      {Array.from({ length: totalSteps }, (_, i) => {
        const isCompleted = i < currentStep;
        const isCurrent = i === currentStep;
        
        return (
          <div
            key={i}
            className="flex items-center"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ 
                scale: isCurrent ? 1.1 : 1, 
                opacity: 1 
              }}
              className={`
                w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center font-bold text-xs sm:text-sm
                transition-all duration-300
                ${isCompleted 
                  ? 'bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] text-white' 
                  : isCurrent 
                    ? 'bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] text-white shadow-lg' 
                    : 'bg-gray-200 dark:bg-gray-700 text-gray-400'
                }
              `}
              style={{
                boxShadow: isCurrent ? '0 4px 12px rgba(107, 54, 255, 0.4)' : 'none'
              }}
            >
              {isCompleted ? <Check className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : i + 1}
            </motion.div>
            {i < totalSteps - 1 && (
              <div 
                className={`w-6 sm:w-8 h-0.5 mx-1 transition-colors duration-300 ${
                  isCompleted ? 'bg-[#6B36FF]' : 'bg-gray-200 dark:bg-gray-700'
                }`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
};

export default function ConditionFilters({
  conditionAxes,
  conditionLabels,
  selectedLabelIds,
  setSelectedLabelIds,
  allowances,
  allowanceConditions,
  editingAxisId,
  onEditComplete
}) {
  const [localSelectedLabelIds, setLocalSelectedLabelIds] = useState(selectedLabelIds || {});
  const [currentAxisIndex, setCurrentAxisIndex] = useState(0);

  useEffect(() => {
    if (editingAxisId !== null && editingAxisId !== undefined) {
      const axisIndex = conditionAxes.findIndex(a => a.id === editingAxisId);
      if (axisIndex !== -1) {
        setCurrentAxisIndex(axisIndex);
      }
    }
  }, [editingAxisId, conditionAxes]);

  useEffect(() => {
    setLocalSelectedLabelIds(selectedLabelIds || {});
  }, [selectedLabelIds]);

  if (!conditionAxes || conditionAxes.length === 0) {
    return null;
  }

  const currentAxis = conditionAxes[currentAxisIndex];
  if (!currentAxis) return null;

  const availableLabelsForAxis = conditionLabels.filter(label => label.axis_id === currentAxis.id);

  const getFilteredAvailableLabels = () => {
    const selectedSoFar = { ...localSelectedLabelIds };
    delete selectedSoFar[currentAxis.id];
    
    if (Object.keys(selectedSoFar).length === 0) {
      return availableLabelsForAxis;
    }

    const matchingAllowances = allowances.filter(allowance => {
      const entries = allowanceConditions.filter(ac => ac.allowance_id === allowance.id);
      if (entries.length === 0) return false;

      const byAxis = new Map();
      for (const ac of entries) {
        const axis = String(ac.axis_id);
        const label = String(ac.label_id);
        if (!byAxis.has(axis)) byAxis.set(axis, new Set());
        byAxis.get(axis).add(label);
      }

      return Object.entries(selectedSoFar).every(([selectedAxisId, selectedLabelId]) => {
        const axis = String(selectedAxisId);
        const label = String(selectedLabelId);
        if (!byAxis.has(axis)) return true;
        return byAxis.get(axis).has(label);
      });
    });

    const matchingLabelIds = new Set();
    for (const allowance of matchingAllowances) {
      const entries = allowanceConditions.filter(
        ac => ac.allowance_id === allowance.id && String(ac.axis_id) === String(currentAxis.id)
      );
      for (const entry of entries) {
        matchingLabelIds.add(String(entry.label_id));
      }
    }

    return availableLabelsForAxis.filter(label => matchingLabelIds.has(String(label.id)));
  };

  const filteredLabels = getFilteredAvailableLabels();

  const handleLabelSelect = (labelId) => {
    const newSelections = {
      ...localSelectedLabelIds,
      [currentAxis.id]: labelId
    };
    setLocalSelectedLabelIds(newSelections);
    setSelectedLabelIds(newSelections);

    if (currentAxisIndex < conditionAxes.length - 1) {
      setTimeout(() => {
        setCurrentAxisIndex(currentAxisIndex + 1);
      }, 200);
    } else {
      if (onEditComplete) {
        onEditComplete();
      }
    }
  };

  const question = getHumanQuestion(currentAxis.name);

  return (
    <div className="w-full">
      <StepIndicator 
        currentStep={currentAxisIndex} 
        totalSteps={conditionAxes.length} 
      />

      <AnimatePresence mode="wait">
        <motion.div
          key={currentAxis.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          <h3 className="text-base sm:text-lg md:text-xl font-bold mb-3 sm:mb-4 text-center" style={{ color: 'var(--text-primary)' }}>
            {question}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3">
            {filteredLabels.map((label) => {
              const isSelected = localSelectedLabelIds[currentAxis.id] === label.id;
              
              return (
                <motion.button
                  key={label.id}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleLabelSelect(label.id)}
                  className="relative overflow-hidden rounded-lg sm:rounded-xl transition-all duration-200 group"
                  style={{
                    padding: 'clamp(0.75rem, 3vw, 1rem)',
                    border: isSelected 
                      ? '2px solid var(--filter-border-hover)'
                      : '2px solid var(--filter-border)',
                    background: isSelected
                      ? 'linear-gradient(135deg, rgba(107, 54, 255, 0.15), rgba(217, 76, 255, 0.15))'
                      : 'var(--card-bg)',
                    backdropFilter: 'blur(20px)',
                  }}
                >
                  <div className="relative z-10 flex items-center justify-between gap-2">
                    <span 
                      className="text-sm sm:text-base font-semibold text-left flex-1"
                      style={{ 
                        color: isSelected ? 'var(--filter-text-selected)' : 'var(--filter-text)'
                      }}
                    >
                      {formatLabel(label.label)}
                    </span>
                    {isSelected && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center flex-shrink-0"
                      >
                        <Check className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
                      </motion.div>
                    )}
                  </div>

                  {!isSelected && (
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-0 group-hover:opacity-20"
                      initial={{ x: '-100%' }}
                      whileHover={{ x: '100%' }}
                      transition={{ duration: 0.6 }}
                    />
                  )}
                </motion.button>
              );
            })}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}