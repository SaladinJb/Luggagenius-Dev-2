import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function StickyUpsellBar({ airline, purchaseUrl, allowances }) {
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  const shouldShow = airline && allowances && allowances.length > 0 && !isDismissed;

  useEffect(() => {
    setIsDismissed(false);
  }, [airline?.id]);

  useEffect(() => {
    if (!shouldShow) return;

    const handleScroll = () => {
      const scrolled = window.scrollY > 50;
      
      const comparisonBanner = document.getElementById('comparison-banner');
      let hideBecauseBannerVisible = false;
      
      if (comparisonBanner) {
        const rect = comparisonBanner.getBoundingClientRect();
        const viewportHeight = window.innerHeight;
        const bannerMiddle = rect.top + rect.height / 2;
        const viewportMiddle = viewportHeight / 2;
        
        hideBecauseBannerVisible = bannerMiddle <= viewportMiddle;
      }
      
      setIsVisible(scrolled && !hideBecauseBannerVisible);
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, [shouldShow]);

  if (!shouldShow) return null;

  const handleDismiss = () => {
    setIsDismissed(true);
    setIsVisible(false);
  };

  const upgradeCostText = airline.upgrade_cost || 'Contact airline for pricing';

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          className="fixed bottom-0 left-0 right-0 z-50 safe-area-bottom"
        >
          <div 
            style={{ 
              backgroundColor: 'var(--glass-bg-strong)',
              backdropFilter: 'blur(30px) saturate(180%)',
              borderTop: '1px solid var(--border-color)',
              boxShadow: '0 -10px 40px var(--glass-shadow)',
              paddingBottom: 'env(safe-area-inset-bottom)'
            }}
          >
            <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-2.5 sm:py-3 md:py-4">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 sm:gap-3 md:gap-4 flex-1 min-w-0">
                  <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 text-[#6B36FF] flex-shrink-0" />
                  
                  <div className="flex-1 min-w-0">
                    <p className="text-xs sm:text-sm font-bold mb-0 sm:mb-0.5 truncate" style={{ color: 'var(--text-primary)' }}>
                      ✨ Upgrade Available
                    </p>
                    <p className="text-[0.65rem] sm:text-xs hidden sm:block truncate" style={{ color: 'var(--text-secondary)' }}>
                      {airline.upgrade_cost ? `Upgrade for ${upgradeCostText}` : 'Get more baggage allowance'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
                  <Button
                    onClick={() => window.open(airline.baggage_policy_url || airline.official_website_url || purchaseUrl, '_blank')}
                    className="bg-gradient-to-r from-[#6B36FF] to-[#D94CFF] hover:opacity-90 text-white font-bold px-3 sm:px-4 md:px-6 py-2 sm:py-2.5 text-xs sm:text-sm whitespace-nowrap h-auto"
                  >
                    <span className="hidden xs:inline">Upgrade</span>
                    <span className="xs:hidden">Upgrade</span>
                  </Button>
                  
                  <button
                    onClick={handleDismiss}
                    className="p-1.5 sm:p-2 rounded-full transition-colors flex-shrink-0"
                    style={{ backgroundColor: 'transparent' }}
                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'var(--hover-bg)'}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                    aria-label="Dismiss"
                  >
                    <X className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: 'var(--text-tertiary)' }} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}