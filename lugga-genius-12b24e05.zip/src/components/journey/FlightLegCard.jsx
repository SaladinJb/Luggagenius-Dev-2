import React from "react";
import { motion } from "framer-motion";
import { Plane, Edit2, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const formatLabel = (text) => {
  if (!text) return '';
  return text
    .replace(/_/g, ' ')
    .toLowerCase()
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

export default function FlightLegCard({ 
  leg, 
  index, 
  onEdit, 
  onRemove, 
  isEditing,
  showRemove 
}) {
  // If no airline selected yet, show a placeholder card
  if (!leg.airline) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="frosted-glass rounded-xl p-3 sm:p-4 relative"
        style={{
          border: isEditing ? '2px solid #6B36FF' : '1px solid var(--border-color)',
          backgroundColor: isEditing ? 'rgba(107, 54, 255, 0.05)' : 'var(--card-bg)'
        }}
      >
        {/* Leg Number Badge */}
        <div className="absolute top-2 left-2 w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center text-white text-xs sm:text-sm font-bold">
          {index + 1}
        </div>

        {/* Remove Button - Inside card, discrete */}
        {showRemove && (
          <button
            onClick={() => onRemove(leg.id)}
            className="absolute top-2 right-2 w-6 h-6 rounded-md flex items-center justify-center transition-colors"
            style={{ 
              backgroundColor: 'transparent',
              color: 'var(--text-tertiary)'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--hover-bg)';
              e.currentTarget.style.color = 'var(--text-secondary)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
              e.currentTarget.style.color = 'var(--text-tertiary)';
            }}
            aria-label="Remove flight leg"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        <div className="flex items-center justify-center py-8 mt-4">
          <p className="text-sm" style={{ color: 'var(--text-tertiary)' }}>
            Select airline and filters
          </p>
        </div>
      </motion.div>
    );
  }

  const getSelectedLabelsText = (leg) => {
    if (!leg.selectedLabels || leg.selectedLabels.length === 0) return 'No filters selected';
    return leg.selectedLabels.map(l => formatLabel(l.label)).join(' • ');
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="frosted-glass rounded-xl p-3 sm:p-4 relative"
      style={{
        border: isEditing ? '2px solid #6B36FF' : '1px solid var(--border-color)',
        backgroundColor: isEditing ? 'rgba(107, 54, 255, 0.05)' : 'var(--card-bg)'
      }}
    >
      {/* Leg Number Badge */}
      <div className="absolute top-2 left-2 w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center text-white text-xs sm:text-sm font-bold">
        {index + 1}
      </div>

      {/* Remove Button - Inside card, discrete, greyish */}
      {showRemove && (
        <button
          onClick={() => onRemove(leg.id)}
          className="absolute top-2 right-2 w-6 h-6 rounded-md flex items-center justify-center transition-colors"
          style={{ 
            backgroundColor: 'transparent',
            color: 'var(--text-tertiary)'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = 'var(--hover-bg)';
            e.currentTarget.style.color = 'var(--text-secondary)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'transparent';
            e.currentTarget.style.color = 'var(--text-tertiary)';
          }}
          aria-label="Remove flight leg"
        >
          <X className="w-4 h-4" />
        </button>
      )}

      <div className="flex items-start gap-3 mt-6">
        {/* Airline Logo */}
        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-white flex items-center justify-center overflow-hidden flex-shrink-0">
          {leg.airline.logo_url ? (
            <img 
              src={leg.airline.logo_url} 
              alt={leg.airline.airline_name}
              className="w-full h-full object-cover"
            />
          ) : (
            <Plane className="w-5 h-5 sm:w-6 sm:h-6 text-[#6B36FF]" />
          )}
        </div>

        {/* Flight Info */}
        <div className="flex-1 min-w-0">
          <h3 className="text-sm sm:text-base font-bold mb-1 truncate" style={{ color: 'var(--text-primary)' }}>
            {leg.airline.airline_name}
          </h3>
          
          <p className="text-xs mb-2 truncate" style={{ color: 'var(--text-tertiary)' }}>
            {getSelectedLabelsText(leg)}
          </p>

          {/* Edit Button */}
          <Button
            onClick={() => onEdit(leg.id)}
            variant="ghost"
            size="sm"
            className="text-[#6B36FF] hover:text-[#D94CFF] h-auto p-0 text-xs"
          >
            <Edit2 className="w-3 h-3 mr-1" />
            {isEditing ? 'Editing...' : 'Edit'}
          </Button>
        </div>
      </div>
    </motion.div>
  );
}