import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Route } from "lucide-react";
import { Button } from "@/components/ui/button";
import FlightLegCard from "./FlightLegCard";
import SearchBox from "../home/SearchBox";

export default function MultiJourneyManager({
  legs,
  onAddLeg,
  onRemoveLeg,
  onUpdateLeg,
  editingLegId,
  onStartEdit,
  onCompleteEdit
}) {
  const [showAddLeg, setShowAddLeg] = useState(false);

  const handleAirlineSelect = (airline) => {
    if (editingLegId) {
      const currentLeg = legs.find(l => l.id === editingLegId);
      if (currentLeg) {
        onUpdateLeg(editingLegId, { 
          airline,
          conditionAxes: [],
          conditionLabels: []
        });
      }
    }
  };

  const handleFiltersComplete = (filters) => {
    if (editingLegId) {
      onCompleteEdit(editingLegId, filters);
    }
  };

  const handleAddNewLeg = () => {
    const newLegId = `leg-${Date.now()}`;
    onAddLeg(newLegId);
    setShowAddLeg(false);
  };

  const isEditing = editingLegId !== null;
  const canAddMore = legs.length < 4 && !isEditing; // Changed to 4
  const currentEditingLeg = legs.find(l => l.id === editingLegId);

  return (
    <div className="space-y-4">
      {/* Journey Header */}
      {legs.length > 0 && (
        <div className="flex items-center gap-2 mb-2">
          <Route className="w-5 h-5 text-[#6B36FF]" />
          <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
            Your Journey ({legs.length} {legs.length === 1 ? 'Flight' : 'Flights'})
          </h3>
        </div>
      )}

      {/* Flight Legs Grid */}
      <AnimatePresence mode="popLayout">
        {legs.length > 0 && (
          <motion.div
            layout
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4"
          >
            {legs.map((leg, index) => (
              <FlightLegCard
                key={leg.id}
                leg={leg}
                index={index}
                onEdit={onStartEdit}
                onRemove={onRemoveLeg}
                isEditing={editingLegId === leg.id}
                showRemove={legs.length > 1 && !isEditing}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search Box - Only show when editing */}
      {isEditing && currentEditingLeg && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
        >
          <SearchBox
            onAirlineSelect={handleAirlineSelect}
            onFiltersComplete={handleFiltersComplete}
            showResults={false}
            onReset={() => {}}
            externalReset={0}
            currentLeg={currentEditingLeg}
          />
        </motion.div>
      )}

      {/* Add Flight Button */}
      {canAddMore && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex justify-center"
        >
          <Button
            onClick={handleAddNewLeg}
            className="bg-gradient-to-r from-[#6B36FF] to-[#D94CFF] hover:opacity-90 text-white font-semibold px-6 py-3 text-sm sm:text-base"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add Another Flight
          </Button>
        </motion.div>
      )}

      {legs.length >= 4 && (
        <p className="text-xs text-center" style={{ color: 'var(--text-tertiary)' }}>
          Maximum 4 flights per journey
        </p>
      )}
    </div>
  );
}