import React from "react";
import { motion } from "framer-motion";
import { Plane, Package, Weight, Ruler, Briefcase, Shield } from "lucide-react";
import EnforcementWidget from "../allowances/EnforcementWidget";

const typeIcons = {
  "personal_item": Briefcase,
  "carry_on": Package,
  "checked": Weight,
  "special_items": Ruler,
};

const formatType = (type) => {
  if (!type) return '';
  return type
    .replace(/_/g, ' ')
    .toLowerCase()
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

export default function MultiJourneyComparison({ legs, allowancesData }) {
  // Filter out legs without airline data
  const validLegs = legs.filter(leg => leg && leg.airline);
  
  if (!validLegs || validLegs.length === 0) return null;

  // Get unique allowance types across all legs
  const allTypes = new Set();
  Object.values(allowancesData || {}).forEach(legAllowances => {
    if (Array.isArray(legAllowances)) {
      legAllowances.forEach(allowance => {
        if (allowance && allowance.type) {
          allTypes.add(allowance.type);
        }
      });
    }
  });

  const sortedTypes = Array.from(allTypes).sort();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
        <Shield className="w-6 h-6 text-[#6B36FF]" />
        Side-by-Side Comparison
      </h2>

      {/* Enforcement Levels Comparison */}
      <div className="frosted-glass rounded-2xl sm:rounded-3xl overflow-hidden">
        <div className="p-4 sm:p-6" style={{ background: 'linear-gradient(135deg, rgba(107, 54, 255, 0.1), rgba(217, 76, 255, 0.1))' }}>
          <h3 className="text-lg font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
            Enforcement Levels
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {validLegs.map((leg, idx) => (
              <div key={leg.id}>
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-6 h-6 rounded-full bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center text-white text-xs font-bold">
                    {idx + 1}
                  </span>
                  <p className="text-sm font-semibold truncate" style={{ color: 'var(--text-primary)' }}>
                    {leg.airline.airline_name}
                  </p>
                </div>
                {leg.airline.enforcement_grade ? (
                  <EnforcementWidget
                    enforcementLevel={leg.airline.enforcement_grade}
                    enforcementNotes={leg.airline.enforcement_notes}
                  />
                ) : (
                  <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>
                    No enforcement data
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Allowances Comparison by Type */}
      {sortedTypes.map(type => {
        const Icon = typeIcons[type] || Package;
        const displayType = formatType(type);

        return (
          <div key={type} className="frosted-glass rounded-2xl sm:rounded-3xl overflow-hidden">
            <div className="p-4 sm:p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center">
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                  {displayType}
                </h3>
              </div>

              {/* Comparison Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ borderBottom: '2px solid var(--border-color)' }}>
                      <th className="text-left py-3 px-2 font-semibold" style={{ color: 'var(--text-primary)' }}>
                        Flight
                      </th>
                      <th className="text-left py-3 px-2 font-semibold" style={{ color: 'var(--text-primary)' }}>
                        Pieces
                      </th>
                      <th className="text-left py-3 px-2 font-semibold" style={{ color: 'var(--text-primary)' }}>
                        Weight
                      </th>
                      <th className="text-left py-3 px-2 font-semibold" style={{ color: 'var(--text-primary)' }}>
                        Dimensions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {validLegs.map((leg, idx) => {
                      const legAllowances = (allowancesData[leg.id] || []).filter(a => a && a.type === type);
                      
                      if (legAllowances.length === 0) {
                        return (
                          <tr key={leg.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
                            <td className="py-3 px-2">
                              <div className="flex items-center gap-2">
                                <span className="w-5 h-5 rounded-full bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center text-white text-xs font-bold">
                                  {idx + 1}
                                </span>
                                <span className="text-xs truncate" style={{ color: 'var(--text-primary)' }}>
                                  {leg.airline.airline_name}
                                </span>
                              </div>
                            </td>
                            <td colSpan="3" className="py-3 px-2 text-xs" style={{ color: 'var(--text-tertiary)' }}>
                              Not available
                            </td>
                          </tr>
                        );
                      }

                      return legAllowances.map((allowance, allowanceIdx) => (
                        <tr key={`${leg.id}-${allowanceIdx}`} style={{ borderBottom: '1px solid var(--border-color)' }}>
                          {allowanceIdx === 0 && (
                            <td className="py-3 px-2" rowSpan={legAllowances.length}>
                              <div className="flex items-center gap-2">
                                <span className="w-5 h-5 rounded-full bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center text-white text-xs font-bold">
                                  {idx + 1}
                                </span>
                                <span className="text-xs truncate" style={{ color: 'var(--text-primary)' }}>
                                  {leg.airline.airline_name}
                                </span>
                              </div>
                            </td>
                          )}
                          <td className="py-3 px-2 text-xs" style={{ color: 'var(--text-secondary)' }}>
                            {allowance.pieces_allowed || '—'}
                          </td>
                          <td className="py-3 px-2 text-xs" style={{ color: 'var(--text-secondary)' }}>
                            {allowance.weight_limit_kg ? `${allowance.weight_limit_kg} kg` : '—'}
                          </td>
                          <td className="py-3 px-2 text-xs" style={{ color: 'var(--text-secondary)' }}>
                            {allowance.dim_length_cm || allowance.dim_width_cm || allowance.dim_height_cm
                              ? `${allowance.dim_length_cm || '—'} × ${allowance.dim_width_cm || '—'} × ${allowance.dim_height_cm || '—'} cm`
                              : '—'}
                          </td>
                        </tr>
                      ));
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
      })}
    </motion.div>
  );
}