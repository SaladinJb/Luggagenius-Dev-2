import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Sparkles, Loader2, AlertCircle, ExternalLink, Plane, DollarSign, Package, Ruler, Weight, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useUnitSystem } from "../UnitSystemProvider";

export default function GeniusPackerAI({ journey1, journey2 }) {
  const [isLoading, setIsLoading] = useState(true);
  const [analysis, setAnalysis] = useState(null);
  const [error, setError] = useState(null);
  const { unitSystem, getDimensionUnit, getWeightUnit } = useUnitSystem();

  useEffect(() => {
    if (journey1?.airline && journey2?.airline && journey1?.allowances && journey2?.allowances) {
      analyzeJourney();
    }
  }, [journey1, journey2]);

  const analyzeJourney = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const [allAllowances1Res, allAllowances2Res] = await Promise.all([
        fetch(
          `https://ejwzyaipwxxnrkcmjelx.supabase.co/rest/v1/allowances?airline_id=eq.${journey1.airline.id}&purchase_status=ilike.included&select=*`,
          { 
            headers: { 
              apikey: 'sb_publishable_ZjLVjnPNTd0Eg4E3wUJqtA_kRb7a2Ki', 
              Authorization: 'Bearer sb_publishable_ZjLVjnPNTd0Eg4E3wUJqtA_kRb7a2Ki' 
            } 
          }
        ),
        fetch(
          `https://ejwzyaipwxxnrkcmjelx.supabase.co/rest/v1/allowances?airline_id=eq.${journey2.airline.id}&purchase_status=ilike.included&select=*`,
          { 
            headers: { 
              apikey: 'sb_publishable_ZjLVjnPNTd0Eg4E3wUJqtA_kRb7a2Ki', 
              Authorization: 'Bearer sb_publishable_ZjLVjnPNTd0Eg4E3wUJqtA_kRb7a2Ki' 
            } 
          }
        )
      ]);

      const allAllowances1 = await allAllowances1Res.json();
      const allAllowances2 = await allAllowances2Res.json();

      const prompt = `You are an expert travel advisor analyzing a multi-leg flight journey. Determine what the traveler can pack for the ENTIRE journey and recommend the smartest upgrade.

CRITICAL RULE - ONE BAG CONCEPT:
The traveler brings PHYSICAL BAGS. A "Personal Item" and "Carry-On" are NOT two separate bags if both airlines only allow 1 bag each - it's ONE physical bag that gets called different names.

EXAMPLE:
- Airline A: "Personal Item - 1 piece, 40cm × 20cm × 25cm, no weight limit"
- Airline B: "Carry-On - 1 piece, 56cm × 45cm × 25cm, 8kg max"

CORRECT: Traveler brings ONE bag:
- Dimensions: 40cm × 20cm × 25cm (Airline A's smaller size)
- Weight: 8kg max (Airline B's limit)
- Called "Personal Item" on Flight A, "Carry-On" on Flight B

JOURNEY DETAILS:
Flight 1: ${journey1.airline.airline_name}
Flight 2: ${journey2.airline.airline_name}

CURRENT FILTERS:
Flight 1: ${JSON.stringify(journey1.filters || {})}
Flight 2: ${JSON.stringify(journey2.filters || {})}

CURRENT ALLOWANCES:
Flight 1: ${JSON.stringify(journey1.allowances, null, 2)}
Flight 2: ${JSON.stringify(journey2.allowances, null, 2)}

ALL AVAILABLE ALLOWANCES FOR UPGRADES:
Flight 1: ${JSON.stringify(allAllowances1, null, 2)}
Flight 2: ${JSON.stringify(allAllowances2, null, 2)}

UPGRADE INFO:
Flight 1: Cost: ${journey1.airline.upgrade_cost || 'Not specified'}, Benefits: ${journey1.airline.upgrade_benefits || 'Not specified'}
Flight 2: Cost: ${journey2.airline.upgrade_cost || 'Not specified'}, Benefits: ${journey2.airline.upgrade_benefits || 'Not specified'}

IMPORTANT FOR UPGRADE RECOMMENDATIONS:
- When recommending an upgrade, CHECK BOTH AIRLINES' new allowances
- DO NOT recommend adding a 2nd bag on one airline if the other airline still only allows 1 bag
- The upgrade must result in USABLE additional allowance across BOTH flights OR remove the bottleneck

YOUR TASK:
1. Calculate total PHYSICAL bags allowed (minimum between both airlines)
2. For each bag, find MOST RESTRICTIVE: dimensions, weight, special rules
3. Recommend ONE upgrade that actually improves the journey (considering BOTH airlines)`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            current_allowance: {
              type: "object",
              properties: {
                total_bags: { type: "number", description: "Number of physical bags allowed" },
                max_dimensions: { type: "string", description: "Most restrictive dimensions, e.g., '40 × 20 × 25 cm'" },
                max_weight: { type: "string", description: "Most restrictive weight, e.g., '8 kg' or 'No limit'" },
                special_restrictions: { type: "string", description: "Any special rules like 'must fit under seat', or null" },
                bottleneck_airline: { type: "string", description: "Which airline creates the main restriction" }
              }
            },
            upgrade_recommendation: {
              type: "object",
              properties: {
                airline_to_upgrade: { type: "string", description: "Which airline to upgrade" },
                airline_index: { type: "number", description: "1 or 2" },
                upgrade_to: { type: "string", description: "What class/tier to upgrade to" },
                new_total_bags: { type: "number", description: "Number of bags after upgrade" },
                new_dimensions: { type: "string", description: "New dimensions after considering both airlines" },
                new_weight: { type: "string", description: "New weight limit after considering both airlines" },
                cost: { type: "string", description: "Upgrade cost" },
                why_this_works: { type: "string", description: "Brief explanation why this upgrade helps the full journey" }
              }
            }
          }
        }
      });

      setAnalysis(response);
    } catch (err) {
      console.error("Error analyzing journey:", err);
      setError("Unable to generate recommendations. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  if (!journey1?.airline || !journey2?.airline) {
    return null;
  }

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="frosted-glass rounded-xl sm:rounded-2xl p-4 sm:p-6"
        style={{ 
          background: 'linear-gradient(135deg, rgba(107, 54, 255, 0.1), rgba(217, 76, 255, 0.1))',
          borderColor: 'var(--border-color)'
        }}
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center">
            <Loader2 className="w-5 h-5 text-white animate-spin" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
              Genius Packer AI
            </h2>
            <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>
              Analyzing your journey...
            </p>
          </div>
        </div>
        <div className="space-y-2">
          <div className="h-3 rounded-full" style={{ backgroundColor: 'var(--hover-bg)', width: '80%' }} />
          <div className="h-3 rounded-full" style={{ backgroundColor: 'var(--hover-bg)', width: '60%' }} />
        </div>
      </motion.div>
    );
  }

  if (error) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="frosted-glass rounded-xl sm:rounded-2xl p-4 sm:p-6"
        style={{ borderColor: 'var(--border-color)' }}
      >
        <div className="flex items-center gap-3 mb-3">
          <AlertCircle className="w-5 h-5 text-red-500" />
          <h2 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
            Analysis Unavailable
          </h2>
        </div>
        <p className="text-sm mb-3" style={{ color: 'var(--text-secondary)' }}>{error}</p>
        <Button 
          onClick={analyzeJourney}
          className="bg-gradient-to-r from-[#6B36FF] to-[#D94CFF] hover:opacity-90 text-white"
        >
          Try Again
        </Button>
      </motion.div>
    );
  }

  if (!analysis) return null;

  const upgradeAirline = analysis.upgrade_recommendation?.airline_index === 1 
    ? journey1.airline 
    : journey2.airline;

  const upgradeUrl = upgradeAirline?.baggage_policy_url || upgradeAirline?.official_website_url || '#';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="frosted-glass rounded-xl sm:rounded-2xl overflow-hidden"
      style={{ borderColor: 'var(--border-color)' }}
    >
      {/* Header */}
      <div 
        className="p-4 sm:p-5"
        style={{ 
          background: 'linear-gradient(135deg, rgba(107, 54, 255, 0.15), rgba(217, 76, 255, 0.15))',
          borderBottom: '1px solid var(--border-color)'
        }}
      >
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
              Genius Packer AI
            </h2>
            <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>
              Smart packing for your multi-flight journey
            </p>
          </div>
        </div>
      </div>

      <div className="p-4 sm:p-5">
        {/* Current Allowance - Compact Grid Layout */}
        {analysis.current_allowance && (
          <div className="mb-4">
            <h3 className="text-sm font-bold mb-3 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
              <Package className="w-4 h-4" style={{ color: '#6B36FF' }} />
              What You Can Pack
            </h3>
            
            {/* Grid Layout - 2 columns on mobile, 3 on desktop */}
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-3">
              {/* Total Bags */}
              <div 
                className="rounded-lg p-3"
                style={{ 
                  backgroundColor: 'var(--card-bg)',
                  border: '1px solid var(--border-color)'
                }}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Package className="w-4 h-4" style={{ color: 'var(--text-tertiary)' }} />
                  <p className="text-xs font-semibold" style={{ color: 'var(--text-tertiary)' }}>
                    Total Bags
                  </p>
                </div>
                <p className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                  {analysis.current_allowance.total_bags}
                </p>
              </div>

              {/* Dimensions */}
              <div 
                className="rounded-lg p-3"
                style={{ 
                  backgroundColor: 'var(--card-bg)',
                  border: '1px solid var(--border-color)'
                }}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Ruler className="w-4 h-4" style={{ color: 'var(--text-tertiary)' }} />
                  <p className="text-xs font-semibold" style={{ color: 'var(--text-tertiary)' }}>
                    Max Size
                  </p>
                </div>
                <p className="text-sm font-bold" style={{ color: 'var(--text-primary)' }}>
                  {analysis.current_allowance.max_dimensions.replace(/cm/g, getDimensionUnit()).replace(/\d+/g, match => {
                    if (unitSystem === 'imperial') {
                      return Math.floor(parseInt(match) * 0.393701);
                    }
                    return match;
                  })}
                </p>
              </div>

              {/* Weight */}
              <div 
                className="rounded-lg p-3"
                style={{ 
                  backgroundColor: 'var(--card-bg)',
                  border: '1px solid var(--border-color)'
                }}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Weight className="w-4 h-4" style={{ color: 'var(--text-tertiary)' }} />
                  <p className="text-xs font-semibold" style={{ color: 'var(--text-tertiary)' }}>
                    Max Weight
                  </p>
                </div>
                <p className="text-sm font-bold" style={{ color: 'var(--text-primary)' }}>
                  {analysis.current_allowance.max_weight.replace(/kg/g, getWeightUnit()).replace(/\d+/g, match => {
                    if (unitSystem === 'imperial') {
                      return Math.floor(parseInt(match) * 2.20462);
                    }
                    return match;
                  })}
                </p>
              </div>
            </div>

            {/* Special Restrictions & Bottleneck - Full Width Alert */}
            {(analysis.current_allowance.special_restrictions || analysis.current_allowance.bottleneck_airline) && (
              <div 
                className="rounded-lg p-3 flex items-start gap-2"
                style={{ 
                  backgroundColor: 'var(--warning-yellow-bg)',
                  border: '1px solid var(--warning-yellow-border)'
                }}
              >
                <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: 'var(--warning-yellow)' }} />
                <div className="flex-1 min-w-0">
                  {analysis.current_allowance.special_restrictions && (
                    <p className="text-xs font-medium mb-1" style={{ color: 'var(--text-primary)' }}>
                      {analysis.current_allowance.special_restrictions}
                    </p>
                  )}
                  {analysis.current_allowance.bottleneck_airline && (
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                      Most restrictive: {analysis.current_allowance.bottleneck_airline}
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Upgrade Recommendation - Compact Card */}
        {analysis.upgrade_recommendation && (
          <div>
            <div 
              style={{ 
                borderTop: '1px solid var(--border-color)', 
                paddingTop: '1rem',
                marginBottom: '0.75rem'
              }}
            />
            
            <div 
              className="rounded-xl p-4"
              style={{ 
                background: 'linear-gradient(135deg, rgba(107, 54, 255, 0.08), rgba(217, 76, 255, 0.08))',
                border: '2px solid rgba(107, 54, 255, 0.3)'
              }}
            >
              <div className="flex items-start gap-2 sm:gap-3 mb-3">
                <DollarSign className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: '#6B36FF' }} />
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-bold mb-0.5" style={{ color: 'var(--text-primary)' }}>
                    Recommended Upgrade
                  </h4>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                    Increase your allowance across both flights
                  </p>
                </div>
              </div>

              {/* Two Column Layout on Desktop */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 mb-3">
                {/* Left: Airline & Upgrade Info */}
                <div className="space-y-3">
                  {/* Airline Card */}
                  <div 
                    className="rounded-lg p-3 flex items-center gap-2"
                    style={{ 
                      backgroundColor: 'var(--glass-bg-strong)',
                      border: '1px solid var(--border-color)'
                    }}
                  >
                    <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center overflow-hidden p-1.5 flex-shrink-0">
                      {upgradeAirline?.logo_url ? (
                        <img 
                          src={upgradeAirline.logo_url} 
                          alt={upgradeAirline.airline_name}
                          className="w-full h-full object-contain"
                        />
                      ) : (
                        <Plane className="w-4 h-4 text-[#6B36FF]" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs mb-0.5" style={{ color: 'var(--text-tertiary)' }}>
                        Upgrade
                      </p>
                      <p className="text-sm font-bold truncate" style={{ color: 'var(--text-primary)' }}>
                        {analysis.upgrade_recommendation.airline_to_upgrade}
                      </p>
                    </div>
                  </div>

                  {/* Upgrade To & Cost */}
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-xs font-semibold mb-1" style={{ color: 'var(--text-tertiary)' }}>
                        Upgrade To
                      </p>
                      <p className="text-xs font-medium" style={{ color: 'var(--text-primary)' }}>
                        {analysis.upgrade_recommendation.upgrade_to}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold mb-1" style={{ color: 'var(--text-tertiary)' }}>
                        Cost
                      </p>
                      <p className="text-xs font-bold" style={{ color: '#6B36FF' }}>
                        {analysis.upgrade_recommendation.cost}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Right: New Allowance */}
                <div>
                  <p className="text-xs font-semibold mb-2" style={{ color: 'var(--text-tertiary)' }}>
                    New Allowance
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Package className="w-3.5 h-3.5" style={{ color: 'var(--text-tertiary)' }} />
                      <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                        {analysis.upgrade_recommendation.new_total_bags} bag{analysis.upgrade_recommendation.new_total_bags !== 1 ? 's' : ''}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Ruler className="w-3.5 h-3.5" style={{ color: 'var(--text-tertiary)' }} />
                      <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                        {analysis.upgrade_recommendation.new_dimensions.replace(/cm/g, getDimensionUnit()).replace(/\d+/g, match => {
                          if (unitSystem === 'imperial') {
                            return Math.floor(parseInt(match) * 0.393701);
                          }
                          return match;
                        })}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Weight className="w-3.5 h-3.5" style={{ color: 'var(--text-tertiary)' }} />
                      <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                        {analysis.upgrade_recommendation.new_weight.replace(/kg/g, getWeightUnit()).replace(/\d+/g, match => {
                          if (unitSystem === 'imperial') {
                            return Math.floor(parseInt(match) * 2.20462);
                          }
                          return match;
                        })}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Why This Works */}
              {analysis.upgrade_recommendation.why_this_works && (
                <div 
                  className="rounded-lg p-3 mb-3"
                  style={{ 
                    backgroundColor: 'var(--note-bg)',
                    border: '1px solid var(--note-border)'
                  }}
                >
                  <p className="text-xs" style={{ color: 'var(--note-text)' }}>
                    💡 {analysis.upgrade_recommendation.why_this_works}
                  </p>
                </div>
              )}

              {/* CTA Button */}
              <Button
                onClick={() => window.open(upgradeUrl, '_blank')}
                className="w-full bg-gradient-to-r from-[#6B36FF] to-[#D94CFF] hover:opacity-90 text-white font-bold py-2.5 text-sm"
              >
                Upgrade Now
                <ExternalLink className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}