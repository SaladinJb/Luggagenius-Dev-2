import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Sparkles, Loader2, AlertTriangle, CheckCircle, Package, ShoppingCart, TrendingUp, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";

// Helper function to safely convert values to strings
const safeStringify = (value) => {
  if (!value) return 'Not specified';
  if (typeof value === 'string') return value;
  if (typeof value === 'object') {
    // If it's an object with allowance details, format it nicely
    const parts = [];
    if (value.pieces) parts.push(`${value.pieces} piece(s)`);
    if (value.weight_kg) parts.push(`${value.weight_kg} kg`);
    if (value.dimensions_cm) {
      const dims = value.dimensions_cm;
      if (dims.length || dims.width || dims.height) {
        const dimStr = [dims.length, dims.width, dims.height]
          .filter(d => d)
          .join(' × ');
        if (dimStr) parts.push(`${dimStr} cm`);
      }
    }
    return parts.length > 0 ? parts.join(' • ') : JSON.stringify(value);
  }
  return String(value);
};

export default function GeniusPackAdvice({ legs, allowancesData }) {
  const [advice, setAdvice] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const validLegs = legs.filter(leg => leg && leg.airline);

  useEffect(() => {
    if (validLegs.length > 0 && allowancesData && Object.keys(allowancesData).length > 0) {
      generateAdvice();
    }
  }, [validLegs.length, allowancesData]);

  const generateAdvice = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const journeyData = validLegs.map((leg, idx) => ({
        flight_number: idx + 1,
        airline: leg.airline.airline_name,
        enforcement_level: leg.airline.enforcement_grade || 'unknown',
        enforcement_notes: leg.airline.enforcement_notes || '',
        upgrade_cost: leg.airline.upgrade_cost || 'Not available',
        baggage_policy_url: leg.airline.baggage_policy_url || leg.airline.official_website_url,
        conditions: leg.selectedLabels?.map(l => l.label).join(', ') || 'standard',
        allowances: (allowancesData[leg.id] || []).map(a => ({
          type: a.type,
          pieces: a.pieces_allowed,
          weight_kg: a.weight_limit_kg,
          dimensions_cm: {
            length: a.dim_length_cm,
            width: a.dim_width_cm,
            height: a.dim_height_cm
          }
        }))
      }));

      const prompt = `You are a genius travel packing assistant. Analyze this multi-flight journey and provide CONCISE, structured advice.

Journey Details:
${JSON.stringify(journeyData, null, 2)}

Provide:
1. MAXIMUM SHARED ALLOWANCE: The most restrictive allowance that works across ALL flights without any upgrades. Return as simple text strings, e.g., "1 piece, 7kg, 45×35×20 cm". Be specific and concise.

2. UPGRADE OPPORTUNITIES: If upgrading one or more flights would significantly improve the overall allowance, suggest it. Consider:
   - Enforcement levels (strict airlines are higher priority for upgrades)
   - Cost-benefit (mention upgrade costs if available)
   - Strategic allowance type changes (e.g., checked → carry-on if dimensions permit on next flight)
   
3. SMART PACKING STRATEGY: Can any bags be reclassified between flights? For example, can a checked bag on Flight 1 become a carry-on on Flight 2 if dimensions permit?

Keep responses concise - use bullet points, not long paragraphs. Always return text strings, never objects.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            maximum_shared_allowance: {
              type: "object",
              properties: {
                summary: { type: "string" },
                personal_item: { type: "string" },
                carry_on: { type: "string" },
                checked: { type: "string" }
              }
            },
            upgrade_opportunities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  flight_number: { type: "string" },
                  airline: { type: "string" },
                  reason: { type: "string" },
                  benefit: { type: "string" },
                  estimated_cost: { type: "string" },
                  priority: { type: "string" }
                }
              }
            },
            smart_strategies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  strategy: { type: "string" },
                  details: { type: "string" }
                }
              }
            }
          }
        }
      });

      setAdvice(response);
    } catch (err) {
      console.error("Error generating advice:", err);
      setError("Unable to generate packing advice. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  if (validLegs.length === 0) return null;

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="frosted-glass rounded-2xl sm:rounded-3xl p-6 sm:p-8 text-center"
      >
        <Loader2 className="w-12 h-12 mx-auto mb-4 text-[#6B36FF] animate-spin" />
        <p className="text-lg font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
          Analyzing Your Journey...
        </p>
        <p className="text-sm" style={{ color: 'var(--text-tertiary)' }}>
          Our Genius Pack AI is finding the optimal strategy
        </p>
      </motion.div>
    );
  }

  if (error) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="frosted-glass rounded-2xl sm:rounded-3xl p-6 sm:p-8"
      >
        <div className="flex items-center gap-3 mb-4">
          <AlertTriangle className="w-6 h-6 text-red-500" />
          <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Error</h3>
        </div>
        <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>{error}</p>
        <Button onClick={generateAdvice} variant="outline">
          Try Again
        </Button>
      </motion.div>
    );
  }

  if (!advice) return null;

  return (
    <div className="space-y-4">
      {/* Maximum Shared Allowance - Primary Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="frosted-glass rounded-2xl sm:rounded-3xl overflow-hidden"
      >
        <div className="p-6 sm:p-8" style={{ background: 'linear-gradient(135deg, rgba(107, 54, 255, 0.15), rgba(107, 207, 127, 0.15))' }}>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-[#6B36FF] to-[#6BCF7F] flex items-center justify-center">
              <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
              Maximum Shared Allowance
            </h2>
          </div>
          <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>
            Pack within these limits to avoid fees on all flights
          </p>
        </div>

        <div className="p-6 sm:p-8 grid gap-4">
          {advice.maximum_shared_allowance?.summary && (
            <p className="text-base font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
              {safeStringify(advice.maximum_shared_allowance.summary)}
            </p>
          )}
          
          <div className="grid sm:grid-cols-3 gap-3">
            {advice.maximum_shared_allowance?.personal_item && (
              <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--card-border)' }}>
                <Package className="w-5 h-5 text-[#6B36FF] mb-2" />
                <p className="text-xs font-semibold mb-1" style={{ color: 'var(--text-tertiary)' }}>Personal Item</p>
                <p className="text-sm" style={{ color: 'var(--text-primary)' }}>
                  {safeStringify(advice.maximum_shared_allowance.personal_item)}
                </p>
              </div>
            )}
            
            {advice.maximum_shared_allowance?.carry_on && (
              <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--card-border)' }}>
                <Package className="w-5 h-5 text-[#6B36FF] mb-2" />
                <p className="text-xs font-semibold mb-1" style={{ color: 'var(--text-tertiary)' }}>Carry-on</p>
                <p className="text-sm" style={{ color: 'var(--text-primary)' }}>
                  {safeStringify(advice.maximum_shared_allowance.carry_on)}
                </p>
              </div>
            )}
            
            {advice.maximum_shared_allowance?.checked && (
              <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--card-border)' }}>
                <Package className="w-5 h-5 text-[#6B36FF] mb-2" />
                <p className="text-xs font-semibold mb-1" style={{ color: 'var(--text-tertiary)' }}>Checked Bag</p>
                <p className="text-sm" style={{ color: 'var(--text-primary)' }}>
                  {safeStringify(advice.maximum_shared_allowance.checked)}
                </p>
              </div>
            )}
          </div>
        </div>
      </motion.div>

      {/* Upgrade Opportunities */}
      {advice.upgrade_opportunities && advice.upgrade_opportunities.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="frosted-glass rounded-2xl sm:rounded-3xl overflow-hidden"
        >
          <div className="p-6 sm:p-8" style={{ background: 'linear-gradient(135deg, rgba(217, 76, 255, 0.15), rgba(255, 217, 61, 0.15))' }}>
            <div className="flex items-center gap-3">
              <TrendingUp className="w-6 h-6 text-[#D94CFF]" />
              <h3 className="text-lg sm:text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                Upgrade Opportunities
              </h3>
            </div>
          </div>

          <div className="p-6 sm:p-8 space-y-3">
            {advice.upgrade_opportunities.map((upgrade, idx) => {
              const isPriority = upgrade.priority?.toLowerCase() === 'high';
              const leg = validLegs.find((l, i) => i + 1 === parseInt(upgrade.flight_number));
              
              return (
                <div 
                  key={idx}
                  className="p-4 rounded-xl relative overflow-hidden"
                  style={{ 
                    backgroundColor: isPriority ? 'var(--warning-yellow-bg)' : 'var(--card-bg)',
                    border: isPriority ? '1px solid var(--warning-yellow-border)' : '1px solid var(--card-border)'
                  }}
                >
                  {isPriority && (
                    <div className="absolute top-2 right-2">
                      <span className="px-2 py-0.5 rounded-full text-xs font-bold" style={{ backgroundColor: 'var(--warning-yellow)', color: 'white' }}>
                        Priority
                      </span>
                    </div>
                  )}
                  
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#6B36FF] to-[#D94CFF] flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                      {upgrade.flight_number}
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-sm mb-1" style={{ color: 'var(--text-primary)' }}>
                        {safeStringify(upgrade.airline)}
                      </p>
                      <p className="text-sm mb-2" style={{ color: 'var(--text-secondary)' }}>
                        {safeStringify(upgrade.reason)}
                      </p>
                      <p className="text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                        ✨ {safeStringify(upgrade.benefit)}
                      </p>
                      <div className="flex items-center gap-3 flex-wrap">
                        <span className="text-sm font-bold text-[#6B36FF]">
                          {safeStringify(upgrade.estimated_cost)}
                        </span>
                        {leg?.airline?.baggage_policy_url && (
                          <a
                            href={leg.airline.baggage_policy_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs font-semibold text-[#6B36FF] hover:text-[#D94CFF] flex items-center gap-1"
                          >
                            Upgrade Now
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}

      {/* Smart Strategies */}
      {advice.smart_strategies && advice.smart_strategies.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="frosted-glass rounded-2xl sm:rounded-3xl p-6 sm:p-8"
        >
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
            <Sparkles className="w-5 h-5 text-[#6B36FF]" />
            Smart Packing Strategies
          </h3>
          <div className="space-y-3">
            {advice.smart_strategies.map((strategy, idx) => (
              <div key={idx} className="flex items-start gap-3">
                <span className="text-[#6B36FF] font-bold flex-shrink-0">💡</span>
                <div>
                  <p className="text-sm font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>
                    {safeStringify(strategy.strategy)}
                  </p>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                    {safeStringify(strategy.details)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}